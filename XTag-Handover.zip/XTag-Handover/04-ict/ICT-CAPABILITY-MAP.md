# XTag ↔ ICT — Capability Map

A desk-by-desk mapping of what XTag supplies, what it does not, and how to phrase its output in
an ICT publication. Companion to Part I of the handover guide.

Institutional structure taken from ict.org.il, September 2026.

---

## 1. The capability matrix

Rows are XTag capabilities. Columns are ICT desks. ● = directly useful, ○ = partially useful,
blank = not relevant.

| Capability | Influence | Cyber | Iran & Shi'ite | Palestinian | Media | Antisemitism / Far-Right | Global Jihad | Psychology | Resilience |
|---|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|:-:|
| Multilingual collection (100+ langs via GDELT) | ● | ● | ● | ● | ● | ● | ● | ○ | ○ |
| State-media monitoring in native language | ● | ○ | ● | ● | ● | ○ | ○ | | ○ |
| Relevance gate with audit trail | ● | ● | ● | ● | ● | ● | ● | ○ | ○ |
| Narrative extraction (frames + key claims) | ● | ● | ● | ● | ● | ● | ○ | ● | ○ |
| Persistent narrative identity over time | ● | ● | ● | ● | ● | ● | ○ | ○ | ● |
| Coordination detection (actor-trait) | ● | ● | ● | ● | ○ | ● | ○ | | ○ |
| Captured vs manufactured reach | ● | ● | ● | ● | ○ | ○ | | | |
| Inauthenticity signals (campaign shape) | ● | ● | ● | ● | ○ | ● | | | |
| Narrative laundering (state → unattributed) | ● | ● | ● | ● | ● | ○ | | | |
| Entity + relationship extraction | ● | ● | ● | ● | ○ | ● | ● | ○ | ○ |
| Geographic breadth + concentration band | ● | ○ | ● | ● | ● | ● | ○ | | ○ |
| Audience inference from language mix | ● | ○ | ● | ● | ● | ○ | ○ | ○ | |
| Native-language sentiment + framing | ○ | ○ | ● | ● | ● | ● | ○ | ● | ○ |
| Real-world event extraction | ● | ○ | ● | ● | ○ | ● | ○ | ○ | ● |
| Velocity + surge detection (σ above baseline) | ● | ● | ● | ● | ● | ● | ○ | | ● |
| Watchlists + alerting | ● | ● | ● | ● | ○ | ● | ○ | | ● |
| Scheduled recurring reports | ○ | ● | ○ | ○ | ○ | ○ | ○ | | ● |
| Threat + four-dimension risk scoring | ● | ● | ● | ● | ○ | ● | ○ | | ● |
| Red-team campaign injection (exercises) | ● | ● | | | | | | | ○ |

CBRN and Terrorism & International Law are omitted: XTag has nothing to offer either beyond
generic media monitoring, and claiming otherwise would be the first thing to discredit it.

---

## 2. Services

| ICT service | Fit | What XTag supplies |
|---|---|---|
| **Threat Assessment & Risk Analysis** | Strong | Four separately-owned risk dimensions (reputational, information integrity, operational, physical security), each with factors, weights, real contributions, coverage and caveats. The operational dimension is withheld unless a client subject is explicitly configured, so a report cannot silently assert a subject nobody entered |
| **War Games & Simulations** | Strong | The injection harness generates synthetic influence campaigns of six distinct evasion types with known ground truth — a ready-made red-team component. Blue team analysts try to find a campaign that provably exists |
| **Consulting** | Moderate | A countable, dated, multilingual evidence base with a stated collection method, produced in minutes rather than weeks |
| **Counter-Terror Financing & Due Diligence** | None | Out of scope |
| **Counter-Terrorism Legal Support** | None | Out of scope |

---

## 3. Publication case reviews

For each, the honest position is the same: XTag would not have written the publication and would
not have replaced its analysis. It would have converted qualitative assertions into measured,
citable evidence — and in three cases surfaced material the manual method structurally cannot
reach.

### Bibi Gate: Handala Hack Team — A Mask for Iranian Psychological Warfare (31 Dec 2025)
*Terrorism & Cyber Desk / Influence Desk*

The load-bearing claim is amplification: who carried the persona's output, how fast, and whether
they moved together. XTag supplies the actor clusters with the traits that linked them
(canonical URL, hashtag set, text shingle, five-minute posting bucket), the coordination
magnitude with a baseline ratio, the reach split against Ferrara's 0.1–5.3% reference band, and
the propagation chain with per-hop lag.

**Including the negative result.** A persona that turns out not to be coordinately amplified is
itself a finding, and one the current method cannot produce because it has no way to say "we
looked and it was not there."

### Exposing Hezbollah's Influence Warfare — The Al-Khanadeq Media Channel (27 Nov 2025)
*Influence Desk*

This is the question XTag was originally built to answer. Telegram public-channel collection,
actor clustering across X, Telegram and TikTok, and the captured-versus-manufactured split
quantifying how much of the channel's measurable reach is its own accounts.

### Iran's Information Warfare During the Dec 2025 – Jan 2026 Protests (4 Feb 2026)
*Influence Desk*

A two-month, multi-language, multi-audience window. XTag supplies the GDELT volume series with
the peak expressed in standard deviations above baseline, the source-country breakdown, the
language breakdown as an audience proxy, the tone trend showing whether framing hardened, and —
because narrative identity persists — a dated record of which narratives were born, grew,
drifted onto a different subject, and died.

### Iranian TikTok Campaign Seeks to Shape War Perceptions Using AI (20 Jun 2025)
*Influence Desk / Cyber Desk*

Direct fit. XTag has a TikTok collector with region selection and hashtag-feed support, and its
relevance gate exists precisely because platform rankers substitute the nearest token they can
match. **Configuration note:** `TIKTOK_REGION` defaults to `US`, which is the wrong regional
proxy for Persian-language work. One line.

### A Narrative of Victimhood, a Message of Victory (19 Mar 2026) · From Missiles to Minds (9 Apr 2026)
*Influence Desk*

Both are narrative-structure arguments, and XTag's narrative object is exactly what they
describe: a labelled recurring frame with a one-sentence key claim, an emotional framing, a
document count, and the specific documents carrying it. The tracking layer turns a snapshot into
a trajectory.

### Cyber-Terrorism Desk Monthly Trend Report (recurring)
*Terrorism & Cyber Desk*

The clearest operational fit in the catalogue. A standing query set on a schedule, producing a
dated snapshot with mention counts, coordination scores, sentiment, narrative births and deaths,
and a first-versus-last delta against stored history. XTag already does this as an email
subscription; the desk defines the query set.

### From Gaming to Grooming (far-right recruitment) · Magic City GTA5 · The Assassination of Charlie Kirk
*Antisemitism & Far-Right Desk*

Partial fit, stated honestly. Discord, Roblox, Steam and in-game environments are not XTag
sources, and that is where the primary material sits. XTag covers the surrounding public
discourse on X, Telegram, TikTok, Reddit and YouTube, the amplification structure, and the
real-world-events extraction. It does not do the ethnographic work.

---

## 4. How to phrase XTag findings in a publication

The value of XTag output in a publication is that it is checkable. That only survives if it is
phrased carefully. These are the correct and incorrect formulations.

| Do not write | Write instead |
|---|---|
| "The campaign was coordinated." | "A coordination magnitude of 74 was measured across 21 actors linked by shared canonicalised URLs and five-minute posting buckets, against a matched organic baseline of 6 for comparable queries in the same period — a ratio of 12×." |
| "The accounts were bots." | "The accounts show campaign-shape signals: verbatim reposting of 40+ character texts by 9 distinct handles, and bulk-registration handle patterns in 23% of the actor set. No claim is made about automation; account age and follower graphs were not available." |
| "Sentiment was strongly negative." | "Of 214 documents, 168 were scored and 46 were not; net sentiment across the scored set was −0.42." |
| "The narrative originated on Telegram." | "The earliest collected document was on Telegram. Platform coverage is uneven — Telegram here is a 20-channel list — so a narrative beginning somewhere less well covered would appear to start where collection is strongest." |
| "The threat level is high." | "Narrative threat 61 (high), confidence 38 (low). Confidence is limited by corpus size (74 documents) and by a 16-month date span in which only 31% of documents fall inside the 90-day recency window." |
| "The narrative has grown 240%." | "The narrative's document count rose 240%; its share of the corpus rose 9%, within the ±10% band. This is collection volume, not narrative growth." |
| "No coordination was detected." | "No actor cluster of three or more met the similarity threshold. With 14 documents this is below the eight-document floor at which the detector reports a result at all — this is not a finding of authenticity." |

**The five additions.** The evidence review conducted during the build found that nine published
reports from a leading commercial narrative-intelligence firm never stated N, the date range, the
source count, or the languages; carried no confidence language, no alternative hypotheses, and no
intelligence-gaps section; and asserted every coordination judgement rather than showing it.

An ICT publication built on XTag can state all five, and four of them already exist in the
payload:

1. **N and time window on every claim** — `totals`, `threat.inputs.timespan_hours`
2. **A matched organic baseline for every coordination number** — once `COORDINATION_BASELINE` is set
3. **Calibrated confidence, separate from severity** — `threat.confidence`, `confidence_drivers`
4. **Explicit alternative hypotheses** — fandom, breaking news, cross-posting, wire syndication,
   and why each was rejected. The wire-syndication guard already does this in code
5. **An intelligence-gaps section** — the relevance report, `gdelt.degraded`, `engine_errors`,
   `sentiment.unscored` and `source_timings` together are that section

That combination is available to ICT immediately, and it is the one thing funded commercial
competitors cannot copy quickly, because copying it means publishing their own numbers.

---

## 5. What to say to a client, and what not to

**Say:** XTag measures coordination against a published method with a measured detection floor;
it shows what it dropped and why; its scores decompose into factors; and it refuses to produce a
severity band where the evidence does not support one.

**Do not say:** that it detects bots, predicts violence, identifies individuals, monitors private
communications, or has calibrated threat weights. It does none of those things, and the first
person to check will find out.
