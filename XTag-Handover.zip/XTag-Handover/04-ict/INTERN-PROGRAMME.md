# XTag Intern Programme — Ten Projects

Ten projects, each scoped to eight to twelve weeks, each producing something ICT can publish or
operate, each mapped to a named desk. Four of them improve XTag itself, which is how the tool
compounds instead of decaying.

Each entry states: the desk, the prerequisite skill level, the week-by-week shape, the
deliverable, and what the supervisor should watch for.

**A note on why this list exists.** The recurring failure of a twelve-week research internship is
that the intern spends four weeks acquiring collection technique and produces a literature-shaped
paper the desk could have written faster itself. With a running XTag instance, week one produces
a countable, dated, multilingual corpus with the collection method stated. The scarce resource
becomes interpretation — which is the thing the internship is supposed to teach.

---

## 1. Set and publish XTag's detection floor

**Desk:** Influence · **Level:** analytical, light Python · **Improves XTag:** yes

The single highest-value task available. XTag's coordination detector currently returns a
magnitude with no risk band, because `COORDINATION_BASELINE` is unset and the design refuses to
band a number it cannot compare against.

| Weeks | Work |
|---|---|
| 1–2 | Assemble twenty queries representative of ICT's real work across Arabic, Persian, Hebrew and English. Run each; keep the corpora |
| 3–5 | Run `harness.sweep()` and `harness.baseline_ratio()` against each. Record recall, precision, SMISC and breaking point per campaign type per size |
| 6–8 | Analyse: where does detection fail, and on which evasion? Set `COORDINATION_BASELINE` from the measurement |
| 9–10 | Write the methodology note |

**Deliverable:** a published detection benchmark — recall and precision by campaign type and
size, the smallest detectable campaign, and the baseline ratio. **No vendor in this category
publishes one.**

**Watch for:** an intern who sets the baseline from a single query, or from an average that hides
variance across languages. The whole point of the design is that the baseline must be *matched*.

---

## 2. Backtest the threat score

**Desk:** Influence / Cyber · **Level:** strong Python + data · **Improves XTag:** yes

XTag's eight threat weights were set from domain reasoning and validated against synthetic
scenarios. They are transparent; they are not calibrated.

| Weeks | Work |
|---|---|
| 1–2 | Identify ten publicly attributed influence operations with known active windows |
| 3–6 | Reconstruct each corpus from GDELT's BigQuery archive for the relevant window |
| 7–9 | Score with `intel.assess()`; compare score trajectory against the attribution timeline |
| 10–12 | Either propose a calibration, or write the honest statement of what the score tracks |

**Deliverable:** a calibration, or a published statement of the score's limits. Both are worth
publishing; the second is worth more than an uncalibrated claim.

**Watch for:** overfitting to ten incidents and presenting it as calibration.

---

## 3. A twelve-month narrative time series

**Desk:** Iran & Shi'ite Terrorism (or Palestinian) · **Level:** analytical, no coding

Pick one channel, persona or media operation. Run a weekly watchlist for the whole placement and
beyond, and analyse the narrative lifecycle.

| Weeks | Work |
|---|---|
| 1 | Define the query set and alert rules; set the watchlist running |
| 2–10 | Weekly observation. Log every birth, growth, drift, split, merge and death event with its date |
| 8–12 | Write it up as a narrative-lifecycle study |

**Deliverable:** a publication that can say "N-2871, first seen 14 May, +34% this week, split
Tuesday" and mean it — which no snapshot-based study can.

**Watch for:** the intern reading `growth` events without checking whether they are `held_share`.
Growth is judged on share of corpus, not raw count, and the distinction is the whole value of the
tracker.

---

## 4. Replicate a persona study with measured coordination

**Desk:** Terrorism & Cyber · **Level:** analytical

Take an existing ICT hacktivist-persona publication and re-derive its amplification claims with
XTag: actor clusters, the traits that linked them, the flagged documents, the baseline ratio, the
reach split.

**Deliverable:** either a strengthened version of the original argument with measured evidence
attached, or an honest note on where the measurement disagrees. Both are publishable; the second
is more interesting.

**Watch for:** the temptation to only publish the confirming result. The value of this project is
that it can disconfirm.

---

## 5. The Telegram channel-selection methodology

**Desk:** Global Jihad / Palestinian · **Level:** analytical, light config · **Improves XTag:** yes

XTag's Telegram source is a fixed list of twenty channels — a research decision currently sitting
in the code as a default.

| Weeks | Work |
|---|---|
| 1–3 | Establish selection criteria: what makes a channel worth standing collection? |
| 4–8 | Build and validate an expanded list; measure what each channel actually contributes |
| 9–10 | Document the coverage gap that remains after expansion |

**Deliverable:** a reusable channel set with a stated selection method, and an explicit statement
of what Telegram coverage does *not* see. The second half matters more.

---

## 6. Wire semantic clustering and run the invariance probe

**Desk:** technical · **Level:** strong Python · **Improves XTag:** yes

`embeddings.py` is fully built and tested and unused on the live path. As a result, a narrative
restated in genuinely different vocabulary splits into two — measured TF-IDF cosine for a real
paraphrase is 0.11–0.13, which no lexical threshold separates from 0.00.

| Weeks | Work |
|---|---|
| 1–2 | Read `narratives.py` and `embeddings.py`; get a Voyage key; reproduce the paraphrase limitation |
| 3–6 | Wire embeddings into the tracking path; switch the join threshold to `SEMANTIC_JOIN_SIM` |
| 7–9 | Validate: BERTScore of claims against source documents, plus a **language-invariance probe** — a classifier that can guess a document's source language from its extracted claim is telling you the claims are not language-invariant |
| 10–12 | Measure the improvement and write it up |

**Deliverable:** narratives that survive paraphrase across languages, and a measured statement of
by how much.

**Watch for:** partial degradation. The module's contract is that a failure is total, never
partial — half-semantic, half-lexical clustering is worse than either and impossible to describe
honestly. Do not let an intern "improve" that.

---

## 7. Claim extraction

**Desk:** technical / Influence · **Level:** strong Python · **Improves XTag:** yes

The largest analytical upgrade available. XTag's current unit of analysis is the document. The
right unit is the **claim**:

```
document → {claim, target, stance, frame} → claim cluster (= narrative) → cluster over time
```

Stance, framing, coordination, migration and narrative whitespace are all ill-defined against a
document and trivial against a claim. Public reference code exists (Gerard et al., WWW'26).

| Weeks | Work |
|---|---|
| 1–2 | Read `xtag-direction.md` and the reference implementation |
| 3–7 | Implement one extraction pass per document |
| 8–11 | Re-base narrative clustering on claims; compare against the current output on the same corpora |
| 12 | Write up |

**Watch for:** scope. This is a twelve-week project for a strong developer and a six-month
project for anyone else. Do not pair it with a publication deadline.

---

## 8. The coverage matrix

**Desk:** any · **Level:** analytical, no coding

For twenty queries across five languages, measure what each of the sixteen sources actually
returned: document counts, languages, date ranges, relevance-gate keep rates, error rates.

**Deliverable:** a document stating precisely what XTag can and cannot see. This is the thing no
commercial vendor publishes and the thing every analyst using the tool needs. It is also the
cheapest project on this list and one of the most useful.

---

## 9. A red-team exercise for the War Games programme

**Desk:** Simulations service · **Level:** analytical + facilitation

Use the injection harness to place a synthetic influence campaign of known ground truth into a
live corpus, then run a blue-team exercise: can analysts find it, how long does it take, and what
do they conclude?

| Weeks | Work |
|---|---|
| 1–3 | Learn the harness; generate campaigns at three difficulty levels including the adaptive one |
| 4–6 | Design the exercise: briefing, injects, scoring, debrief |
| 7–10 | Run it with two cohorts; measure time-to-detection and error types |
| 11–12 | Package it as a repeatable module |

**Deliverable:** a repeatable exercise, and a measurement of human analyst performance against a
known ground truth — which INCAS argued matters more than classifier F1.

---

## 10. The decision layer

**Desk:** Influence · **Level:** analytical + light frontend

XTag currently ends at a score. It should end at a decision. The defensive equivalent of a
commercial narrative platform's per-narrative "play" is: **monitor · investigate · attribute ·
escalate · dismiss** — with the reason attached, and with *dismiss* said loudly, because most of
what looks coordinated is organic.

| Weeks | Work |
|---|---|
| 1–3 | Define the decision rules from the payload fields that already exist |
| 4–7 | Implement per-narrative recommendation with attached reasoning |
| 8–10 | Test against historical cases: would an analyst have agreed? |
| 11–12 | Write up the rule set as a doctrine document |

**Deliverable:** a report that ends in a decision rather than a number, and a written rule set
that can be argued with.

---

## Supervision notes

**Give every intern Part II of the handover guide in week one.** It is the analyst-level
explanation of what each measurement is entitled to claim. An intern who has not read §13
("Reading an XTag assessment") will quote a threat score without its confidence figure, which is
the single most likely way this tool produces a bad publication.

**Insist on the phrasing table** in `ICT-CAPABILITY-MAP.md` §4 for anything that goes out under
ICT's name.

**The four XTag-improving projects (1, 2, 6, 7) need a code reviewer.** They are not
self-supervising, and projects 6 and 7 in particular can silently weaken the honesty guarantees
the tool depends on. Have someone read the diff against §15 of the guide.

**Projects 1 and 8 are the two to run first.** They are cheap, they are publishable, and they
make every subsequent project's claims defensible.
