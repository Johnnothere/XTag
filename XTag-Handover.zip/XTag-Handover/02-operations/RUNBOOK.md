# XTag — Operations Runbook

Everything needed to deploy, monitor, diagnose and recover XTag. Written for whoever is holding
the pager, not for whoever wrote the code.

---

## 1. Deploy

XTag deploys from the repository root. Both `Procfile` and the Dockerfile `CMD` are identical:

```
gunicorn app:app --bind 0.0.0.0:$PORT --workers 1 --threads 8 --timeout 300
```

### On Railway (current deployment)
1. New project → Deploy from GitHub → select the XTag repository.
2. Railway detects the Dockerfile. Set `MISE_PYTHON_GITHUB_ATTESTATIONS=false` — a builder
   workaround, required.
3. Add environment variables (see `ENV-REFERENCE.md`). `PORT` is supplied by Railway.
4. Deploy, then hit `/healthz?deep=1`.

### Anywhere else
Any host that can run the Dockerfile works. The image is `python:3.11-slim` plus the Chromium
dependency set (needed only by the NotebookLM sync thread — remove that feature and the image
shrinks considerably).

### Database
Run the three files in `supabase/migrations/` against a Supabase project, oldest first. Then
**check which of the two `report_subscriptions` migrations actually applied** — both use
`CREATE TABLE IF NOT EXISTS` and they differ. See §7.

### DO NOT raise `--workers` above 1
The search cache, watchlists, rate-limit buckets, the GDELT rate limiter and the GDELT circuit
breaker are all process-local. Two workers means two disjoint memories and double the GDELT
request rate. Move that state to Redis or the existing Postgres first.

---

## 2. Health checks

### `GET /healthz`
Shallow. Process memory only, no outbound calls. Safe to poll — it used to make a billed
Anthropic call, a database write and a live GDELT fetch on every hit, which made the liveness
probe itself a recurring line item.

### `GET /healthz?deep=1`
Real probes, cached for 120 seconds. Read these four fields:

| Field | What a bad value means |
|---|---|
| `persistence.writable` | **`false` with `reachable: true` almost always means you set the anon key, not the service_role key.** All tables are RLS deny-all, so the anon key connects fine and silently writes nothing |
| `claude` | A real 16-token probe. 401 = key rejected. 400 = often an unknown model ID. 429 = rate limited or out of credit |
| `gdelt` | Live reachability, which transport is in use (`https` or `http`), and breaker state |
| `mailer` | Whether Resend is configured and which sender is set |

### `GET /api/status`
No outbound calls. Config booleans per source, embeddings backend, watchlist and channel counts.
Use this to answer "why is platform X returning nothing".

---

## 3. Routine operations

| Task | Frequency | How |
|---|---|---|
| Check deep health | Weekly | `/healthz?deep=1` |
| Watch API spend | Weekly | Anthropic, ScrapeBadger, SerpApi dashboards. YouTube quota resets daily at midnight Pacific |
| Rotate keys | Quarterly, and on any personnel change | See the guide, §38 |
| Prune the cache | Automatic | `search_cache` is pruned probabilistically on writes. **Never** on reads |
| Back up | Monthly | `watchlist_snapshots` and `alerts` are the irreplaceable tables. Everything else regenerates |

### Scheduled email reports
Driven by an **external** cron, not by a worker process:

```
POST https://<host>/api/reports/run
X-Cron-Token: <REPORTS_CRON_TOKEN>
```

Refuses to run if the token is unset. `?limit=` defaults to 25 subscriptions per call. Use
`POST /api/reports/test` with `{email, query}` for a single immediate send.

---

## 4. Diagnosing a bad search

Work down this list in order. Each step is answerable from the response payload itself.

**1. Did collection work?** Read `source_timings` in the response — sorted slowest-first, with
abandoned sources marked `ABANDONED`. That entry is the most important one on the list.

**2. Did the relevance gate over-filter?** Read `relevance.by_platform` for kept/dropped counts,
and `platforms[*].filtered` for a sample of what was dropped and why. Re-run with
`?relevance=off` to see the unfiltered corpus. Do not remove the gate; lower `RELEVANCE_MIN`.

**3. Are narratives and entities empty?** Check `engine_errors`. If a Claude error is recorded,
the payload will explicitly say the analysis is empty *because of it*, not because nothing was
found. Below 5 documents, entity extraction declines by design and reports
`insufficient_evidence` — a correct refusal, not a fault.

**4. Is the band `unknown`?** That means coverage below 25% or fewer than 8 documents. It is not
an all-clear and it is not a bug.

**5. Is coordination unbanded?** That is the default state. `COORDINATION_BASELINE` is unset. See
the guide, §11.4.

**6. Is GDELT degraded?** `gdelt.degraded[]` names which of the four analytics stages were lost.
Stages run in value-if-lost order (tone → geography → audience → volume), so losing volume is
cheap and losing geography is expensive.

---

## 5. Common failures and what they actually mean

| Symptom | Cause | Fix |
|---|---|---|
| Everything works, nothing persists | Anon key instead of service_role | `/healthz?deep=1` → `persistence.writable` |
| YouTube suddenly returns nothing | Daily quota exhausted (100 units per search call, 10,000/day) | Wait, or reduce `MAX_PAGES` |
| TikTok returns nothing at all | `TIKTOK_REGION` wrong, or a ScrapeBadger 402 | Check `/debug/scrapebadger` — 402 is an empty wallet, 401 is a wrong key |
| Reddit returns nothing for a hashtag | Reddit's official search does not do hashtags | Expected. The ScrapeBadger fallback covers it |
| Bluesky says "requires auth" | `BLUESKY_IDENTIFIER` / `_APP_PASSWORD` unset | Set them |
| Podcasts returns 401 | `PODCASTINDEX_KEY` / `_SECRET` unset | Set them |
| GDELT slow or empty | Stochastic 429s, or TLS interception on the egress path | Check `gdelt` in deep health for the transport in use. Do not lower `GDELT_RETRY_ATTEMPTS` |
| Search times out entirely | A hung source holding the pool | `source_timings` names it. The request budget is 240s against gunicorn's 300s |
| Streaming delivers everything at once | A proxy buffering the response | `X-Accel-Buffering: no` must survive to the client; `text/event-stream` must never be in `COMPRESS_MIMETYPES` |
| Email report shows a confident coordination `0` | Should be impossible — regression | `test_mailer_db.py` pins this. Run the suite |
| A watchlist "disappeared" | Process restarted, or someone raised the worker count | Watchlists persist to Supabase; the in-memory copy does not survive a redeploy |

---

## 6. Recovery

**The process restarted.** Expected consequences: the search cache is empty (the Supabase copy
survives), watchlists reload from the database, the GDELT breaker resets, rate-limit buckets
reset, and the NotebookLM knowledge bank re-syncs from scratch. No action needed.

**The database is unreachable.** XTag keeps running on in-memory state. You lose history, the
time series, narrative identity across runs, and subscriptions (which 503). Nothing else breaks.

**The Anthropic key is dead.** Collection, the relevance gate, coordination, velocity,
propagation, GDELT analytics and the whole assessment layer still work — they are deterministic.
You lose narratives, entities, events, sentiment, translation and briefs, and the payload will
say so.

**A bad deploy.** Roll back in Railway. There is no migration that needs reversing unless you
added one; the schema is additive.

---

## 7. Known operational hazards

1. **The two `report_subscriptions` migrations conflict.** Both create the same tables with
   different definitions and both use `IF NOT EXISTS`. Whichever ran first won. They differ in
   the deliveries timestamp column, index names, unsubscribe-token entropy (144 vs 244 bits) and
   whether `pgcrypto` is required. Verify against the live database before documenting anything.
2. **Narrative identity lives in `search_cache` under `nt:<query>` with a 90-day TTL.** The cache
   pruner is therefore also the reaper for narrative identity. A query left unobserved for more
   than 90 days loses its narrative IDs permanently.
3. **`watchlist_snapshots` is never pruned** and is the irreplaceable table. Back it up.
4. **`/api/watchlist/check-all` is rate-limited to 2 per hour** and capped at 10 watchlists per
   call, because each one is a full uncached search.
5. **`DEBUG_TOKEN` unset means the debug routes are closed.** It used to mean *open*, which
   leaked the live SerpApi key. Do not "fix" this by removing the check.
6. **`XTAG_API_KEY` unset means the money-spending routes are open** to anyone with the URL. This
   default exists so an existing deployment does not break on upgrade. Set it.

---

## 8. Test suite

```bash
bash tests/run.sh
```

No dependencies, no network. Twelve Python suites and five Node suites. A suite that produces no
result line counts as a failure, not a pass.

Run it before every deploy. The coordination suite contains regression guards against the
injection harness (recall ≥ 90% and precision ≥ 85% for every campaign type at n=32; exactly 0 on
organic-only corpora across five seeds), which is the check that matters most.

---

## 9. The measurement harness

```bash
python harness.py
```

Prints three tables: a sweep of recall/precision/SMISC by campaign size and type, the breaking
point per campaign type, and the baseline table. This is how you produce a defensible answer to
"would XTag have caught this?" and how you obtain the value for `COORDINATION_BASELINE`.

It is not a runtime component. Nothing in `app.py` imports it; it imports `app`.
