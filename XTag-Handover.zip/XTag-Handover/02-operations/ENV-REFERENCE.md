# XTag — Environment Variable Reference

Nothing is strictly required to boot. Every unset credential degrades one source or feature by
name, and everything else keeps running. `PORT` is supplied by the host.

---

## 1. Credentials

| Variable | Used for | Unset behaviour |
|---|---|---|
| `ANTHROPIC_API_KEY` | Every model call: narratives, entities, events, sentiment, translation, query expansion, briefs, knowledge-bank chat | **No narrative engine at all.** Collection and the deterministic assessment layer still work |
| `SUPABASE_URL` | Persistence base URL, e.g. `https://<ref>.supabase.co` | In-memory state only |
| `SUPABASE_SERVICE_KEY` *(or `SUPABASE_SERVICE_ROLE_KEY`)* | Persistence auth. **Must be the service_role key** — tables are RLS deny-all, so the anon key connects and silently writes nothing | In-memory state only |
| `SCRAPEBADGER_KEY` | X/Twitter, TikTok, Instagram, Reddit fallback | Those platforms report "not configured" |
| `SERPAPI_KEY` | Google web + site-restricted Facebook, LinkedIn, Threads, Pinterest, Tumblr, Bluesky | Those platforms dark |
| `YOUTUBE_API_KEY` | YouTube Data API v3 | YouTube dark |
| `REDDIT_CLIENT_ID`, `REDDIT_CLIENT_SECRET` | Official Reddit API (script-type app). 100 req/min vs 10 unauthenticated | Falls back to ScrapeBadger |
| `BLUESKY_IDENTIFIER`, `BLUESKY_APP_PASSWORD` | Authenticated Bluesky | Public API 403s: "requires auth" |
| `PODCASTINDEX_KEY`, `PODCASTINDEX_SECRET` | Podcast Index SHA-1 auth | Podcasts returns 401 |
| `BABELSTREET_API_KEY` | Optional second sentiment engine | Claude handles sentiment alone |
| `OPENALEX_MAILTO` | OpenAlex polite pool | Defaults to a placeholder; 429s become likely |
| `VOYAGE_API_KEY`, `VOYAGE_MODEL` | Embeddings (preferred backend), default `voyage-3-lite` | Embeddings unavailable — currently unused on the live path anyway |
| `OPENAI_API_KEY`, `OPENAI_EMBED_MODEL` | Embeddings fallback, default `text-embedding-3-small` | As above |
| `RESEND_API_KEY` | Email delivery | No email reports |
| `REPORT_FROM` | Sender, default `XTag <onboarding@resend.dev>` | Uses Resend's shared sender. **Set a verified own domain for deliverability** |
| `PUBLIC_BASE_URL` | Unsubscribe and "open in XTag" links | Defaults to the Railway hostname |
| `NOTEBOOKLM_AUTH_1..N` | base64 tar.gz of `~/.notebooklm`, concatenated | Knowledge bank disabled |

---

## 2. Security tokens — set all three

| Variable | Default | Behaviour |
|---|---|---|
| `XTAG_API_KEY` | unset | **Unset means every money-spending route is open.** Set = `X-XTag-Key` required. `?key=` is additionally accepted on the SSE endpoint only, because EventSource cannot set headers |
| `REPORTS_CRON_TOKEN` | unset | **Required.** `/api/reports/run` and `/api/reports/test` refuse to run without it. Sent as `X-Cron-Token` or `?token=` |
| `DEBUG_TOKEN` | unset | **Required.** All eight `/debug/*` routes are closed without it. Sent as `X-Debug-Token`. Keys in debug output are masked to the last four characters |
| `TRUSTED_PROXY_HOPS` | `1` | Number of trusted reverse proxies. Railway appends exactly one. Raise if you add a CDN |

---

## 3. Collection depth and relevance

| Variable | Default | Notes |
|---|---|---|
| `MAX_RESULTS_PER_SOURCE` | `150` | Was 500. Above every observed post-gate keep count |
| `MAX_PAGES` | `2` | Was 10. YouTube costs 100 quota units per search call against 10,000/day; SerpApi bills per page |
| `RELEVANCE_MIN` | `0.35` | Floor a document must clear. Raise toward 0.65 for verified matches only. `?relevance=off` sets 0 for one request |
| `RELEVANCE_AUDIT_SAMPLE` | `20` | Rejected documents retained **per platform** for inspection |
| `TIKTOK_REGION` | `US` | ISO-3166 code selecting ScrapeBadger's regional proxy. **A poor default for MENA/Persian work** |
| `TELEGRAM_CHANNELS` | 20 built-in | Comma-separated, normalised, capped at 60. This is a research decision, not a config detail |
| `MIN_ENTITY_DOCS` | `5` | Below this, entity extraction declines rather than guessing |

---

## 4. Analysis and scoring

| Variable | Default | Notes |
|---|---|---|
| `CLAUDE_MODEL` | `claude-haiku-4-5-20251001` | **Note:** the brief and knowledge-bank chat hardcode the model and do not honour this |
| `COORDINATION_BASELINE` | unset | **Set this.** Unset = every coordination score is returned unbanded with a caveat. Obtain the value from `harness.baseline_ratio()`, never by guesswork |
| `NARRATIVE_TRACKING` | `1` | `0`/`false`/`off` disables persistent narrative identity |
| `NARRATIVE_STATE_TTL` | `7776000` (90 days) | How long narrative identity survives without observation |
| `SEMANTIC_JOIN_SIM` | `0.72` | Embedding-scale clustering threshold. Only relevant once embeddings are wired |
| `XTAG_WATCH_SUBJECT` | unset | Enables the operational risk dimension. **Leave unset unless there is a real subject** — the dimension is withheld rather than inferred |
| `FUTURE_SKEW_TOLERANCE_H` | `2` | Publisher clock drift tolerance. Beyond this, a document is excluded from velocity and counted |
| `VELOCITY_MIN_DOCS` | `5` | Minimum documents before an "accelerating" verdict is allowed |

---

## 5. Timeouts and budgets

| Variable | Default | Notes |
|---|---|---|
| `REQUEST_BUDGET` | `240` | The single wall clock for a search. **Must stay well under gunicorn's 300s** |
| `SEARCH_POOL_TIMEOUT` | `25` | Collection fan-out ceiling, clamped by the budget with a 45s reserve |
| `ANALYSIS_TIMEOUT` | `70` | Shared across all six analysis futures — one deadline, not six |
| `CLAUDE_HTTP_TIMEOUT` | `45` | Per-call HTTP budget |
| `SENTIMENT_BUDGET` | `35` | Shared across up to six language groups |
| `TRANSLATE_BUDGET` | `6` | Display-only translation |
| `QUERY_EXPANSION_TIMEOUT` | `6` | Hard cap — this is on the critical path |
| `GDELT_SNAPSHOT_WAIT` | `6` | Wait for the analytics future, which started at t=0 |
| `SSE_HEARTBEAT` | `10` | Keepalive interval on the streaming endpoint |
| `CHECK_ALL_TIMEOUT` / `CHECK_ALL_MAX` | `240` / `10` | Watchlist bulk check |
| `DEEP_HEALTH_TTL` | `120` | Deep health cache |

---

## 6. GDELT

| Variable | Default | Notes |
|---|---|---|
| `GDELT_RETRY_ATTEMPTS` | `4` | **The single most important number in the file.** GDELT's 429s are stochastic and retryable; lowering this loses analytical stages |
| `GDELT_RETRY_BACKOFF` | `3.0` | Linear seconds, overridden by `Retry-After` (clamped to 30s and to the remaining budget) |
| `GDELT_CALL_BUDGET` | `8` | Total wall clock for one call **including retries and sleeps** |
| `GDELT_TIMEOUT` | `6` | Per attempt |
| `GDELT_MIN_INTERVAL` | `2.0` | Politeness gap. Correct only because `--workers 1` |
| `GDELT_TIMESPAN_HOURS` | `168` | 7-day lookback |
| `GDELT_ARTICLE_WINDOWS` | `1` | Time slices per search; each buys up to 250 more articles. Raise for watchlist depth |
| `GDELT_ANALYTICS_BUDGET` | `110` | Wall clock for the four analytical stages |
| `GDELT_ANALYTICS_TTL` | `3600` | Cache for tone/geography/audience/volume |
| `GDELT_BREAKER_THRESHOLD` | `3` | Consecutive failed **calls** (not attempts) before the breaker opens |
| `GDELT_BREAKER_COOLDOWN` | `180` | Seconds |
| `GDELT_ALLOW_HTTP` | `1` | Permits the HTTPS→HTTP fallback where TLS is intercepted. `0` forbids it. GDELT is unauthenticated public data and no credentials cross the wire, but HTTP is tamperable in principle |

---

## 7. Caches and limits

`CACHE_TTL=1800`, `CACHE_MAX_ENTRIES=200`, `CACHE_MAX_BYTES=48 MiB`,
`QUERY_EXPANSION_CACHE_MAX=1000`, `QX_DB_TTL=2592000` (30 days), `RL_MAX_BUCKETS=20000`,
`RL_BUCKET_TTL=3600`, `EMBED_BATCH=96`, `EMBED_CACHE_MAX=4000`, `EMBED_MAX_CHARS=800`,
`EMBED_TIMEOUT=10`, `NOTEBOOKLM_SYNC_INTERVAL=3600`, `CLAUDE_SENTIMENT_BATCH=120`.

---

## 8. Platform-specific

| Variable | Purpose |
|---|---|
| `MISE_PYTHON_GITHUB_ATTESTATIONS=false` | Railway builder workaround. Required on Railway |
| `PORT` | Supplied by the host |

---

## 9. Minimum viable configuration

```
ANTHROPIC_API_KEY=...
SUPABASE_URL=...
SUPABASE_SERVICE_KEY=...        # service_role, not anon
XTAG_API_KEY=...
REPORTS_CRON_TOKEN=...
DEBUG_TOKEN=...
MISE_PYTHON_GITHUB_ATTESTATIONS=false
```

That gives you GDELT, Google News, Telegram, Mastodon, Hacker News, academic sources, state
media RSS, the entire analysis and scoring layer, history, watchlists and narrative identity —
for the cost of hosting plus model calls. Everything else is additive.
