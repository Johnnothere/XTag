# XTag P5 — persistent narrative identity

**Date:** 2026-09-03 · **New file:** `narratives.py` · **Tests:** `tests/test_narratives.py` (47 checks)
**Wired into:** `_run_full_search` → `payload["narrative_tracking"]`

## The problem

XTag re-derived narratives from scratch on every search. Run the same query twice and "Vaccine data was
falsified" came back as a brand-new object in a new list position, so nothing could be said about it
over time — not whether it was growing, not when it started, not that it had absorbed another narrative.
A watchlist checking hourly produced a pile of unrelated snapshots rather than a history. **The "over
time" in "narrative intelligence over time" did not exist.**

## What was built

Greene et al. (2010) front-matching. Each observation's clusters are matched against the most recent
appearance of every living narrative, and a **stable UUID** carries across the match. A narrative now
has a birth, a life and a death, and change becomes events that happened to a thing rather than
differences between two lists.

- **DP-means clustering** — no *k* to guess, which matters because the number of live narratives is
  exactly what we do not know.
- **Hungarian optimal assignment**, implemented here (no scipy dependency). Greedy matching is the
  tempting shortcut and it is wrong in a specific way: a narrative that fits two current clusters gets
  claimed by whichever is examined first, so **identity would depend on iteration order**.
- **Events**: `birth`, `death`, `growth`, `contraction`, `merge`, `split`, `drift`.
- **Death after 3 consecutive misses, not 1.** Real collection is lossy — a source times out, a rate
  limit hits. Killing identity on the first miss would manufacture a "new" narrative next run and
  destroy the continuity the module exists for.
- **Drift detection.** Greene defines identity by membership, so a narrative keeping its documents keeps
  its id even as wording moves — usually right, since stories evolve. But identity can walk onto a
  different subject one observation at a time. Drift is *reported, not blocked*: blocking would break
  legitimate evolution, but an analyst reading "this narrative has grown for three weeks" deserves to
  know if what it is about changed underneath.

## The measured limitation, stated because it changes how to read the output

Similarity is TF-IDF cosine. Measured on this module's own tokeniser:

| pair | cosine |
|---|---|
| restatement sharing vocabulary | 0.58 – 1.00 |
| **genuine paraphrase, new vocabulary** | **0.11 – 0.14** |
| unrelated documents | 0.00 |

"The ministry falsified vaccine data" and "ministry accused of falsifying vaccination figures" score
**0.14** — against 0.00 for unrelated text. **There is no threshold that captures that pair without also
capturing noise.** So a narrative restated in genuinely different vocabulary *will* split into two, and
no tuning fixes it: lexical overlap is the wrong measurement for semantic identity.

This is exactly what sentence embeddings solve, and the swap changes nothing else in the file — pass
embedding vectors instead of TF-IDF ones and the clustering, tracking and event logic are unchanged.
Until then, read a split narrative as possible over-fragmentation rather than as two separate stories.
The threshold is `JOIN_SIM = 0.45`, chosen to sit cleanly above the 0.00 noise floor.

An earlier version used the DP-means `1 - lambda` formulation, which quietly demanded 0.90 cosine — the
*claim identity* threshold, not the narrative one — and split every narrative into singletons. The
parameter is now an explicit similarity, and the test suite asserts the measured paraphrase gap so that
a future change to the tokeniser surfaces it rather than hiding it.

## Config

`NARRATIVE_TRACKING=1` (set `0` to disable) · `NARRATIVE_STATE_TTL=7776000` (90 days)

State is stored per query in the existing DB cache under `nt:<query>`. The TTL is long deliberately: the
value of a stable id is that it outlives the gap between observations, and a narrative that goes quiet
for a fortnight and returns is the same narrative.

Tracking is best-effort and wrapped: a failure attaches an error to `narrative_tracking` and **never
costs the user their search results**. If state cannot be persisted, this run's events are still valid
and still shown — only continuity into the next run is lost, and the payload says so (`persisted: false`).

## Next

Wire `narrative_tracking` into the frontend timeline as one line per narrative id — that is the chart
this whole module exists to make possible — and into watchlist alerts, so "narrative X grew 140% since
your last check" becomes an alert rather than something the analyst has to notice.
