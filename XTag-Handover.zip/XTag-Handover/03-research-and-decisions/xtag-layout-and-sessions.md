# XTag — split, tab views, and sessions (07 Sep 2026)

Committed to `~/Desktop/XTag`, not pushed. Suite: **708 checks, 0 failures**.
New `tests/test_layout_tabs.mjs` (46 checks). Verified against the real Flask app in Playwright.

## 1. The split is 60/40 and the analyst owns it

`.report-panel` was `width:min(560px,48%)` — on a wide screen the analysis got less room than the
thumbnail grid, and the ratio could not be changed at all.

- Now `width:var(--split,60%)`, defaulting to 60% report / 40% evidence.
- A 9px seam (`.split-h`) between the panes: drag, or arrow keys (Shift = 10% steps),
  Home resets, End maximises, double-click resets to 60/40.
- Clamped 25–75%. Persisted in `localStorage` per browser; one write per drag, not per pixel.
- `EMAP.resize()` + a `resize` event fire on change so the entity map and timeline re-layout.
- Below 860px the seam hides and the layout takes over.

## 2. The tabs were never views — they were the same report with an appendix

**The defect.** `renderReport` rendered ~15 blocks (query, restored bar, finding, changed-since,
limits, events, threat, corpus, brief, stats, engagement, sentiment, framing, languages) and only
*then* branched on `activeMode`. So:

- Clicking **Entities** meant scrolling past the entire narrative report to reach the first actor.
- **Key Entities** rendered on both Narrative and Entities.
- **Geographic Reach** rendered on both Narrative and Entities.
- Inside Entities, the "Key Entities" chip row duplicated the "Actor volume" list — same actors,
  same counts, one scroll apart, and only the chips were clickable.
- Inside Timeline, `renderTimelineView` draws its own Velocity block and its own dated events list,
  and the standalone versions of both were stacked on top of them.

**The fix.** A tab owns its content. What stays above the tabs is the answer, because that is what
every view qualifies: query, restored bar, **the finding**, **the collection-gap banner**, **what
would change this**. Four blocks, not fifteen.

| Tab | Question | Content |
|---|---|---|
| Narrative | what is being said, and how hard | threat breakdown, corpus card, impact/events, brief, stats, engagement, sentiment, framing, narrative clusters, narrative identity |
| Entities | who is saying it, from where, whether authentic | entity map, actors, relationships, coordination, inauthentic amplification, languages, geographic reach |
| Timeline | when it happened, and how it moved | velocity, volume chart, lanes, tracked history, event stream, propagation |

Verified in Playwright against the live template: **zero section-title overlap between any two tabs.**

Also:
- The actor list is now the single clickable one (`entgrid`), counted by `entDocCount` so the number
  on the row is the number the click produces. The duplicate chip row is gone.
- Each tab remembers its scroll position (`tabScroll`), restored on the next frame after the DOM is
  replaced. Re-clicking the active tab no longer re-renders.
- Tab labels carry a tooltip naming the question, and `aria-selected` tracks state.

## 3. The score was still stated twice

Caught on a rendered screenshot: the finding strip gave `Moderate confidence · 47.2 threat ·
elevated`, and 250px below, the threat block restated all three at 84px. The block now leads with
its breakdown (`solo` is false whenever the finding rendered) and keeps the giant number only where
it renders alone. The finding strip also stopped repeating the document count its own first sentence
opens with.

**`solo` is computed from the data, not from `document.querySelector('.finding')`** — the report is
assembled as a string and inserted in one write, so nothing rendered in the pass is in the DOM yet.
That is the same trap that made an earlier de-duplication guard silently never fire; there is a test
asserting the DOM query is not there.

## 4. Sessions — storage was never the problem, the door was

Every search was already being written to IndexedDB (`xtag-cases`) with a localStorage index
(`xtag-hist-v3`), complete with partial/failed states and instant restore. But `.rail-hist` is
`display:none` unless the rail is expanded, and `railExpanded` defaulted to `false` with no
persistence. So the saved searches existed and could not be seen or reached — "+" looked like it
destroyed the previous search, and re-running a query cost a full fan-out for a result already on
disk.

- The rail remembers whether it was open, and opens itself on first visit when there is history.
  (`initRail` is called from BOOT, not inline — it sits above `var HIST_KEY` and `var` hoists the
  declaration without the assignment, so inline it would have read localStorage under the key
  `undefined` and collapsed the rail on exactly the visit this fixes.)
- Collapsed, a `railCount` badge shows how many searches are stored and opens the drawer.
- "+" now confirms: a toast naming the saved query, the drawer opens, and the saved row flashes.
- The restore banner says the restore queried no sources and spent nothing, and that re-running
  collects from scratch.

**Verified end to end:** search → "+" → toast + drawer opens + row flashes + box cleared → click the
saved row → query, 42 cards and the restored banner come back with **zero `/api/` requests**.

## Still open

- M4 — sentiment measures topic valence, not stance toward the subject.
- No embedding backend configured in production (`VOYAGE_API_KEY` / `OPENAI_API_KEY`).
- `COORDINATION_BASELINE` unset — needs 4–6 representative queries through `harness.baseline_ratio()`.
