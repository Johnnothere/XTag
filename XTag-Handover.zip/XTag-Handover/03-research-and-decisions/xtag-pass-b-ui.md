# XTag Pass B — explainability, cases, filters, entity backlinks, timeline

**Date:** 2026-09-01 · **Status:** written to `~/Desktop/XTag`. **Not committed, not pushed.**
**Files:** `templates/index.html` (3374 → 4522 lines), `app.py`, `intel.py`
**Verified:** headless Chromium against the real 530-document `#covid1948` payload. Zero JS errors
across narrative, entities and timeline views, in both themes.

## The finding that shaped this pass

`intel.py` already computed every score from weighted `Factor` objects carrying `score`, `weight`,
`contribution_pct`, `available`, `detail` and `reason`, and every risk dimension already shipped a
plain-English `rationale`. **The frontend rendered almost none of it** — `renderThreatBlock` read
`th.factors` only for `.length`, and the risk grid drew label + number + bar with no rationale, no
coverage, no factors. The explanation Tej asked for already existed in the payload and had never been
put on screen.

## What was built

### Explainability
- **Threat card** → all 8 signals with score, real `contribution_pct` (not configured weight — the
  composite renormalises over available factors, so a signal set at 20 can carry half the number), and
  for unavailable ones the `reason` they dropped out, rendered rather than hidden.
- **Risk grid** → fixed order (was `Object.keys`, so cells reshuffled between searches), per-dimension
  coverage, and a panel per dimension carrying both a written explanation of what the dimension *is*
  and whose problem it is, plus the backend's own `rationale` and factor rows.
- **Confidence** → "a claim about this assessment, never about the threat", with the document count and
  signal coverage it was computed from.
- **Sentiment** → the method that already existed: scored per document in its own language, two engines
  averaged with their agreement %, thresholds ±0.25, and `unscored` explained as deliberately separate
  from neutral.
- **Corpus card** → verified / unverified / dropped, per-platform counts, a sample of removed documents
  with their rejection reasons, and the `&relevance=off` escape hatch.
- **Real-world impact** → the `events[]` from Pass A, each with its quoted evidence.

### Cases (`newSearch` no longer destroys work)
Full payloads in **IndexedDB**, light index in `localStorage`. A case records at search start (so
in-flight and failed searches still appear), completes with band + doc count, and restores instantly
with a "Captured … · Re-run now" banner. Payload eviction is tied to the bounded index so IndexedDB
cannot grow without limit. **"New" opens a case; the previous one stays in the rail.**

### Filter & sort
Filter was deferred behind Apply while Sort applied instantly — two opposite commit models in one
toolbar, and Reset only reset the pending copy. Everything is immediate now; active filters are
**removable chips in the toolbar** (a badge reading "3" says something is hidden but not what);
`aria-expanded` is actually tracked; the sort popover is no longer pinned at a hardcoded `right:110px`.
Added a **Relevance** sort (now the default) and a relevance band filter.

### Entity backlinks (the Obsidian pattern)
Entities came back as `{name, type, mentions, sentiment}` with no join key to the corpus. Now:
- **Local alias matching** in the frontend — complete, instant, no token cost.
- **`quote` added to the extraction prompt**, and **verified against the corpus before display** — a
  fabricated citation is worse than none because it is unfalsifiable to the reader.
- Hover shows the source count; the dossier lists the actual posts in a scrollable pane; "Show these in
  the results grid" filters the grid with a removable chip. The dossier also finally has a background
  (`.em-dos` declared none and floated unbacked over the live canvas).

### Timeline
Rebuilt as a control surface: an SVG volume chart split by sentiment, **drag-to-brush** a window,
hover readout, event markers on the axis, and **platform lanes** — one row per source on the same axis,
which is the only way cross-platform migration renders. On `#covid1948` the lanes show a single tight X
burst in May 2020, YouTube spreading after it, and Google/Google News later still (the reporting *about*
the campaign). Brushed windows push into the grid as a removable chip.

## Two real bugs found while verifying

1. **Invisible platform dots.** X is `#000`, TikTok `#010101`, Threads `#101010`. On the near-black
   theme those markers rendered invisible everywhere they appeared — 19 of 114 X documents in the
   `#covid1948` corpus had no visible marker at all. Added `platCol()`, which substitutes a legible tone
   only when a brand colour collapses into the background, in either theme.
2. **The timeline axis had the same disease as the corpus.** 13 stray documents stretched the axis
   across 8 years and compressed the 65 real May-2020 documents into one bar. A 2/98 percentile trim was
   too weak (15% of documents were outliers), so the window is now the **tightest interval containing
   90% of documents**, with the outlier count disclosed and a one-click return to the full range.

Also fixed: the velocity arrow was a hardcoded trending-up icon even when the verdict was "declining";
`intel.py` reported "spread over 22394.4h" where a reader needs "2.6y" (`_dur()`).

## Open
- **Commit and push are manual.** The device bridge writes `~/Desktop/XTag` but its shell cannot mount
  the folder, so no `git` command runs from a Cowork session.
- The written brief is not stored with a case (it is regenerated on re-run) — deliberate, to keep
  payloads small, but worth revisiting if briefs become the primary artefact.
- Bluesky and Podcast Index still need credentials; that remains a config gap, not a code gap.
