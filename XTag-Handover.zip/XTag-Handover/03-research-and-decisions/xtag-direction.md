# What XTag is for — direction from the SMISC BAA, the Bot Challenge, and Protagonist

**Date:** 2026-09-01 · **Companion artifact:** "What XTag Is For"
**Sources:** DARPA-BAA-11-64 pp.3–8 · Subrahmanian et al. arXiv:1601.05140v2 · Protagonist product detail

## The fork we have not chosen

SMISC and Protagonist are two different products sharing an analysis engine. XTag is drifting between
them, which is why the output layer feels unfinished — it has threat scores and no decisions.

| | **SMISC / INCAS lineage** | **Protagonist lineage** |
|---|---|---|
| Question | Is someone running an operation against us? | What do people believe, and what do we do? |
| Output | Campaign, actors, attribution, evidence | 8–12 beliefs, a play for each |
| Buyer | Security, intelligence, T&S | Comms, brand, policy |
| Failure mode | False accusation | Expensive advice nobody acts on |

**Take the SMISC lineage as the product** — the mandate, sources and languages all say defensive
intelligence. **But steal Protagonist's output grammar.** They don't end at a score; they end at a 2×2
(favourability × engagement, sized by impact) with a named play per narrative: amplify / attach / avoid
/ counter / reframe.

**Defensive equivalent, to be computed per narrative:** monitor · investigate · attribute · escalate ·
**dismiss** (organic — say so loudly, because most of what looks coordinated is). With the reason attached.

## Move 1 — the unit of analysis is wrong: document → claim

Both serious documents converge on this independently.
- Protagonist under the hood: *"scan for argument structures, emotionally charged language, subjectivity,
  claims"* and *"declarative sentences, key entities, subjectivity... to reveal the key assertions."*
  That is argument mining, not topic modelling.
- INCAS TA1 indicators: **Agenda** (what the author wants you to believe/do), **Concerns** (wedge issues,
  sacred values), **Emotions**.

The primitive is the **claim**. Everything composes off it:
`document → claim → claim cluster (= narrative) → cluster over time`
- Stance = author's position toward a claim
- Framing = which frame a claim invokes
- Coordination = accounts co-promoting the same claims
- Migration = a claim cluster appearing on another platform
- Whitespace = a claim that resonates but is under-said

None of these are well-defined against a document; all are trivial against a claim. Current best
narrative-clustering work extracts a canonical claim with an LLM *before* embedding and clustering —
described as the main recent methodological advance in the area.

Implementation: one extraction pass per document → `{claim, target, stance, frame}`.

## Move 2 — ground truth by INJECTION, not annotation

I previously said "annotate 300 documents first." That was half right. The BAA's evaluation section:

> …performance metrics on strategic communication activity **inserted into live data sets by a TA 3 red
> team** in the closed and controlled environment developed by the TA 2 performer.

DARPA didn't discover ground truth, they **authored** it. The Bot Challenge is the same design made
concrete: Pacific Social built a synthetic Twitter environment replaying a redacted real dataset —
7,038 accounts, 4,095,083 tweets, weekly network snapshots — with 39 bots hidden in it. Immediate
right/wrong feedback per guess.

**Scoring function: `FinalScore = Hits − 0.25·Misses + Speed`** (Speed = days remaining when all found).
Sentimetrix won on day 16 of 28: 39/40 correct, 12 speed points. A far better objective than F1 —
analyst time is expensive, and a campaign found after it ran is worthless.

**We can build this now, free.** Synthesise a coordinated campaign with chosen parameters (N accounts,
co-share window, URL overlap, organic cover, duration), inject into a real XTag corpus, measure
recovery. Sweep until the detector breaks.

**What injection gives that annotation cannot:** the *smallest campaign we can detect*. That is a
specification an analyst can act on, and the only honest answer to "would XTag have caught this?"

## Move 3 — seed and expand, don't classify everything

> All three winning parties found that **machine learning techniques alone were insufficient** because
> of lack of training data. However, a semi-automated process that included machine learning proved
> useful. … No team started with unsupervised learning. … No team found existing Sybil detection
> methods useful.

Every winning team used the same workflow:
1. **Find four.** Sentimetrix: 4 initial bots by manual inspection. USC: 4 via outlier detection +
   content analysis + manual inspection.
2. **Expand by similarity.** Sentimetrix 4 → 25 more (clustering + network analysis).
   USC 4 → 21 (network connection to known bots, content/sentiment, semi-supervised clustering).
3. **Only then train.** Sentimetrix used the confirmed set to train an SVM for the final 10.

**Four confirmed seeds → thirty-nine detections.** This dissolves the cold-start problem: XTag doesn't
need a labelled corpus, it needs an analyst who can confirm four accounts and a system that expands.

Supporting details: feature counts grew *during* the competition (Sentimetrix 66 → 175) as each
confirmed bot suggested new discriminators; all three teams built analyst dashboards with per-account
flags and sortable evidence, treated as part of the method not the presentation.

**UI implication:** the entity map already does half of this (click actor → sources → grid). Missing:
**confirm** and **expand**. Mark an account confirmed-coordinated; the map shows nearest neighbours in
the coordination network and why.

## What to take from Protagonist, precisely

1. **Beliefs in the voice of the audience** — *"8–12 beliefs, each boiled down to a paragraph in the
   voice of the audience."* Not a label. A paragraph as the believer would say it. Short generation step
   once claims exist; far better than "disinformation ×22".
2. **Signature — position, not presence.** Defensive version: for a given narrative, which actors
   dominate it and how does share change over time. XTag has actor volume, no share-of-narrative.
3. **Whitespace — measure the absence.** High engagement-per-post, low volume = a narrative working but
   not yet scaled. Nobody in threat-intel measures absence; it's arguably the better early warning, and
   it falls out of claim data free.
4. **Correlate to events, not abstractions.** Their effect measurement is *"12 months of narrative data
   correlated with KPIs and events."* Our equivalent is the shipped `events[]` extraction — correlate
   narrative volume against real-world events on the same axis.

**Not to take:** Protagonist is heavily services-wrapped (*"we convene with key stakeholders"*,
*"Narrative Experts integrate these"*). Their software produces inputs to a consulting engagement. If
XTag is a product not a practice, the decision layer must be computed and defensible on its own.

## Next 90 days

| Phase | Weeks | Deliverable |
|---|---|---|
| **Injection harness** | 1–2 | "Detects a 25-account campaign co-sharing within 120s at 0.9 recall; fails below 12 accounts" |
| **Replace coordination score** | 2–4 | A coordination number with a measured detection floor behind it |
| **Claim extraction + persistent narratives** | 4–7 | "Narrative N-2871, first seen 14 May, +34% this week, split Tuesday" |
| **Seed-and-expand in the UI** | 7–9 | Four clicks to a candidate network, with evidence per expansion |
| **Decision layer** | 9–12 | A report that ends in a decision, not a number |

The harness comes first because it makes phase 2 measurable — we currently have no way to know whether
a change to the coordination score improved anything.

## The through-line

Six teams, four weeks, DARPA money, and the finding was that ML alone was insufficient — what worked was
a semi-automated process where a human confirmed a few, the machine expanded, and the interface made the
reasoning inspectable. INCAS made that structural ten years later with analyst effectiveness (Cohen's d)
above classifier F1. Protagonist arrived at the same architecture commercially from the opposite
direction.

XTag already has the right bones: a relevance gate that shows what it dropped, a threat score that opens
into its factors, an entity map that links back to sources. **The gap is not intelligence, it is
decision.** The report should end by telling an analyst what to do, why, and be wrong in a way they can
see.
