# XTag Entity Map — implementation spec and build log

**Date:** 2026-08-30
**Status:** BUILT. `templates/index.html` on the local repo (`~/Desktop/XTag`) has been patched and dry-run against three live queries. **Not committed, not pushed** — see §6.
**Reference implementation:** `birdseyes.app/network` (BirdsEyes, a React/Vite/Supabase learning app). The relevant code is a lazily-loaded chunk, `NetworkGraph-*.js`, ~1.9k lines when beautified.

## 1. What BirdsEyes actually does

No graph library. No d3-force, no cytoscape, no sigma, no reactflow, no cosmograph. One `<canvas>`, one `requestAnimationFrame` loop, and roughly 600 lines of hand-written layout, physics and drawing. That is the most important finding: the whole effect is reproducible in vanilla JS with no dependency added to XTag.

**Layout — deterministic radial rings, not a force simulation.** Nodes are grouped by `depth_level`, each ring sorted by degree descending, ring radius grown from node count with a golden-angle offset plus a deterministic sine jitter so the rings don't look machined. The anchor map is memoised against a signature of the node ids. Because the layout is deterministic, the same data always draws the same picture — you can reopen a graph and recognise it, which a force layout destroys on every run.

**Physics — spring to anchor, not repulsion.** Each node springs toward its ring anchor (k ≈ 0.04, 0.07 for degree ≤ 1), velocity damped 0.92 per frame, with a low-amplitude sine drift so the map breathes. Overlap is resolved by a spatial-hash grid over a 3×3 neighbourhood, pushing apart any pair closer than `r₁ + r₂ + 8`. Total kinetic energy under 0.001 puts integration to sleep while drawing continues.

**Rendering, back to front:** radial background gradient → cluster "nebula" glow → proximity ghost links → real links as quadratic béziers with a perpendicular control-point offset (scaled by span length and edge index, so parallel edges separate), width and alpha from `value³`, plus a wide low-alpha bloom pass → node halo → node core → progress arc → recency pulse → selection rings → label.

**The one trick worth stealing above all others:** `globalCompositeOperation = "lighter"` in dark mode and `"source-over"` in light. A single boolean gives a glowing dark canvas and a clean light one from identical drawing code.

**Labels:** level-of-detail by zoom and depth, then a greedy rectangle-overlap test against already-drawn label boxes, so text never collides.

**Interaction:** pointer events with capture; pan with inertia (0.92 decay); pinch-zoom around the midpoint; wheel zoom at the cursor; zoom clamped 0.35–8×; 6 px desktop / 12 px mobile tap threshold; minimum hit radius of `22 / zoom` px; link hit-testing by sampling 11 points along the bézier; drag-to-pin; focus mode dropping non-neighbours to ~6 % alpha rather than hiding them; camera lerped toward a target at `1 − 0.88^dt`.

## 2. What XTag already had

`GET /api/search?q=…` returns `entities: {entities:[{name,type,mentions,sentiment}], edges:[{from,relation,to}]}`. Types seen in the wild: `org`, `country`, `person`, `weapon`, `location`, `event`. `renderEntitiesView()` drew this as a grouped list with mention bars plus a flat list of `from → relation → to` rows.

**No backend change was required.** Every value the map draws was already in the payload.

## 3. Design decisions

| Decision | Choice |
|---|---|
| Ring key | BFS hop distance from the highest-mention actor (XTag entities carry no depth field) |
| Node radius | `clamp(7, 30, 6 + 2.1·√mentions)` |
| Fill colour | Entity type, using the `.echip.*` colours already in the stylesheet |
| Ring colour | Sentiment, separated from the fill by a 1.5 px hairline of `--bg` so the two channels read as two channels even when both land on green or red |
| Unlinked actors | Faint dashed outer ring at 0.7× the normal gap — present, visibly outside the network |
| Edges | Directed: curve, arrowhead, relation verb on hover / on selection / past 1.45× zoom, with overlap rejection so verbs never stack |
| Colour source | `getComputedStyle` on `:root` at runtime + a `MutationObserver` on `data-theme`, so the theme toggle is inherited, not duplicated |
| Ring gap | Driven by the node radii either side of the gap, not the total node count — otherwise a two-node ring reserves as much room as a ten-node one and the map deflates |
| Dossier placement | Chosen from the **stage** width, not the viewport: side panel above 620 px, bottom sheet below. The report column is only ~470 px wide at a 1500 px viewport, so a viewport media query would have been wrong. |
| Not ported | XP rings, mastery tiers, streak pulses, confetti, long-press-to-add. Those slots are where **coordination score** and **velocity** would go. |

## 4. What changed in the code

`templates/index.html` only — 672 lines added, 2 changed, in five places:

1. **CSS block** after the existing `/* ENTITIES */` section: `.em-*` classes reusing `--glass-*`, the sentiment triad and the chip colours. No new tokens.
2. **`EMAP` module** before the Entities view: `EMAP.mount(hostId, ents, edges, query)` / `EMAP.destroy()`. Self-contained, vanilla, no build step.
3. **`renderEntitiesView()`** now emits the map host (toolbar, canvas stage, tooltip, dossier, legend) above the actor list. The list survives as the "Actor volume" section — it is the accessible and printable form of the same data, and the report export depends on it.
4. **`renderReport()`** calls `EMAP.destroy()` on entry: every branch replaces `#report` wholesale, so the previous rAF loop and observers must stop before their canvas is discarded.
5. **`wireEntityMap(data)`** is called in the entities branch after `innerHTML` is set — the view is built as a string, so the canvas can only be wired once it exists.

Controls shipped: type/sentiment colour toggle, per-type filter chips with counts, minimum-mentions slider, label mode (auto/all/off), fit, release-pinned, and an expand-to-fullscreen button (Escape exits). The fullscreen button matters more than it sounds — the report column is narrow, and the map is only really usable expanded.

## 5. Dry-run results

Three live `/api/search` payloads pulled from `xtag.up.railway.app`, replayed through the patched page headlessly (Chromium, 1500×1000, 2× DPR):

| Query | Actors / edges | Result |
|---|---|---|
| `#covid1948` | 20 / 15 | Renders; hub = Iran; positive-sentiment actors present, so the full sentiment triad was exercised |
| `#Cyber_Islamic_Resistance` | 20 / 15 | Renders; hub = Cyber Islamic Resistance, 11 direct links; dossier lists all of them |
| `Shehzad Bhatti` | 20 / 15 | Renders; hub = Shehzad Bhatti, 9 links; relation labels with slashes (`rivalry/enmity`) handled |

Also verified: colour-mode toggle, minimum-mentions filter and relayout, light/dark theme switch mid-session, fullscreen enter/exit via button and Escape, node selection and focus dimming, dossier cross-navigation, and teardown when leaving the Entities tab (`#emWrap` gone, rAF cancelled). **Zero JavaScript errors across all three queries.**

One fix found by testing: `ti-pin-off` does not exist in Tabler 3.11 — the correct class is `ti-pinned-off`.

## 6. Open items

- **Not committed or pushed.** The device bridge can read and write files in `~/Desktop/XTag` but its shell cannot mount that folder, so no `git` command can be run from the session. Commit and push has to happen locally, or the mount has to start working.
- Worth considering next: sizing edges by a relationship confidence/weight if the analysis engine can emit one (edges currently carry no weight), and feeding `coordination` and `velocity` into the vacant visual slots.
