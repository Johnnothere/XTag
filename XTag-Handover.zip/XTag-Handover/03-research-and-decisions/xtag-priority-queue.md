# XTag priority queue

**Updated:** 2026-09-04 — P0 through P5 and every fold-in shipped to `~/Desktop/XTag`. Nothing pushed.
**Test suite: `bash tests/run.sh` — 425 checks, 0 failures.**
**Companion docs:** `xtag-detection-measurement.md` (the P3/P4 numbers), `xtag-narrative-identity.md`,
`xtag-build-plan.md`, `xtag-defect-register.md`

---

## Everything shipped

### P0 — money leak and open routes
Four routes gated; rate limiter reads the **last** proxy hop (50 rotating spoofed headers collapse to
one bucket); ad-hoc privilege escalation removed from the watchlist check; `MAX_PAGES` 10 → 2;
degraded searches no longer cached (*transient* failures only, so permanently-dead sources don't
disable caching entirely); X Top/Latest deduped; gzip (269 KB → 72 KB measured).

### P1 — latency and stability
Per-stage `timings` on every payload · GDELT snapshot moved to t=0 (measured wait: 0.0s for a 0.3s
snapshot) · `bounded_pool()` fixed the `shutdown(wait=True)` bug in five more places · `_drain()`
replaced per-future timeouts with one shared deadline (sentiment was 30s × 6 languages = a 180s worst
case wearing a 30s label) · one 240s request budget against `gunicorn --timeout 300` (caps summed to
~510s) · collection cut to 150/source · query expansion bounded and DB-persisted · prompt-injection
boundary on all four analysis prompts · thin corpora report evidence, not engine failure.

**Found during P1 — CRITICAL:** `relevance._doc_text` crashed on every document carrying a `meta`
dict — i.e. all of them. The gate would have 500'd every search on first deploy.

### P2 — two-phase response
`/api/search/stream` sends the corpus, then the interpretation. Frontend reads it with `fetch` + a
stream reader (EventSource can't send the API-key header and can't be aborted). If phase 2 fails after
phase 1 landed, the documents **stay on screen** with an honest banner. `text/event-stream` excluded
from compression and `COMPRESS_STREAMS=False` — flask-compress buffers to compress, which would have
silently turned the stream into one delivery at the end.

### P3 — measurement
`harness.py`: six campaign types × five sizes, SMISC scoring, breaking-point sweep, adaptive adversary.
The harness is itself tested against oracle, null and flag-everything detectors.
**Verdict on the old detector: 0% recall on all six types at every size; 0–96 score on corpora with no
campaign at all, banding pure organic traffic "high".**

### P4 — coordination, rebuilt
`coordination.py`: actor–trait bipartite graph, TF-IDF cosine via inverted index, disparity filter with
an absolute-weight escape hatch (the filter was *removing* the campaign — a uniform clique has nothing
exceptional in it), clustering. Co-URL 0.72 AUC against text similarity's 0.52. URL canonicalisation.
**100% recall, 97–100% precision on all six campaigns; 0 on organic across five seeds.**
Plus: full corpus instead of top-300-by-engagement · wire syndication no longer scored as an operation
(6 syndicated stories were 26/**high**, now 5/low as `info`) · **captured vs manufactured reach**
against Ferrara's 0.1–5.3% band · velocity and propagation moved off the ranked sample, now reporting
`undated`, `sampled_from` and an `origin_caveat` saying "origin" is the earliest document *collected*.

### P5 — persistent narrative identity
`narratives.py`: Greene front-matching, stable UUIDs, Hungarian assignment (greedy would make identity
depend on iteration order), DP-means, death after 3 misses not 1, drift detection.
**Measured limit, stated in the code and asserted in the tests:** TF-IDF scores a genuine paraphrase at
0.14 against 0.00 for unrelated text. No threshold separates those, so vocabulary-shifted restatements
*will* split. Embeddings are the upgrade and change nothing else in the file.

### Fold-in defects — all ten
- **Views out of engagement** — a YouTube view is an impression, not an act. Folding "▶ 2,400,000" into
  reactions let one video outweigh every deliberate interaction in the corpus and is why `_top_docs`
  came to be 85% YouTube. Now its own bucket, reported, excluded from ranking.
- **Source errors survive the merge** — `error: None` as soon as the fallback found anything, so
  "X was rate-limited, these 4 hits are Google's" displayed as a clean X result set.
- **Cross-collector dedupe** — one wire story counted once per collector inflated every ratio.
  Deliberately scoped to article sources: deduping social posts would delete the co-URL evidence that
  the harness showed doing most of coordination's work. The survivor absorbs data from the copy it
  replaces (GDELT has fuller text, the news fallback has the engagement counts).
- **Watchlist and scheduled reports bypass the cache** — an hourly watchlist was recording the same
  30-minute-old payload as several distinct observations: "we did not look" rendered identically to
  "nothing changed".
- **`_claude_last_error` race** — written from six concurrent workers, read while building the payload;
  a torn read spliced one failure's status onto another's message, in the banner that tells the analyst
  *why the analysis is empty*.
- **`report.html` did not exist** — `/report` 500'd on every deployment. Written: print-first, no JS,
  every absent section says why it is absent.
- **GDELT partial state** — abandoned windows were uncounted (a breaker trip on window 1 of 3 reported
  "1 of 3 failed"), malformed windows evaporated silently, completeness was only ever the *absence* of
  an error. Now a first-class `coverage` record.
- **Email report** — the sentiment delta chip was backwards (a collapse painted green, a recovery
  grey); absent coordination printed a confident `0`; `unbanded` can never be painted as a level.
- **`db.py` path injection in five functions** — `watchlist_delete` with `id=eq.{wl_id}` and a crafted
  id turned a one-row DELETE into "delete every watchlist". Now validated and rejected.
- **Cache pruning wired up** — was dead code; `search_cache` only ever grew. Time-gated + probabilistic,
  hung off a write path, never the hot path.

### Also done
Subscriptions migration written (`report_subscriptions`, `report_deliveries`, schema derived from the
db.py functions, not guessed) and the `on_conflict=email,query` bug fixed — without it PostgREST
targets the primary key, so re-subscribing 409'd and surfaced as "could not save subscription".
Frontend renders coordination clusters, reach split, narrative identity with sparklines and events,
propagation caveats, and views separated from engagement.

---

## Left for you

1. **Check the YouTube quota console.** ~1,010 units/search against a 10,000/day default. `MAX_PAGES`
   is now 2 so the arithmetic has changed, but confirm actual consumption.
2. **Deploy and read `timings` off a real `#covid1948` search.** Every latency figure in these
   documents is still derived from code caps rather than measurement — precisely the condition P1-1
   exists to end. The coordination numbers, by contrast, are measured.
3. **Run the subscriptions migration** if you want that feature live.
4. **Set `COORDINATION_BASELINE`** via `harness.baseline_ratio()` on representative queries. Until it
   is set, coordination reports `unbanded` — a magnitude with nothing to compare against. Deliberate
   and correct, but it means no coordination risk band appears in the UI.
5. `MAX_RESULTS_PER_SOURCE` 500 → 150 is a real behaviour change — eyeball one search's counts.

## Still open (nobody has done these)

- **Sentiment → local multilingual model** (P5-3) — needs somewhere for the model to run.
- **Narrative tracking into watchlist alerts** — "narrative X grew 140% since your last check" should
  be an alert, not something the analyst has to notice.
- **Embeddings for claim clustering** — the single highest-value upgrade left; see the 0.14 measurement.
- **An adaptive campaign of 8 accounts posting once each is still invisible** (below the three-actor
  minimum). Stated rather than hidden; it needs co-engagement data XTag does not collect.

## Environment variables

`REQUEST_BUDGET=240` · `SEARCH_POOL_TIMEOUT=90` · `TRANSLATE_BUDGET=20` · `SENTIMENT_BUDGET=35` ·
`SOURCE_DEADLINE=8` · `SSE_HEARTBEAT=10` · `QUERY_EXPANSION_TIMEOUT=6` · `QX_DB_TTL=2592000` ·
`MIN_ENTITY_DOCS=5` · `MAX_RESULTS_PER_SOURCE=150` · `TRUSTED_PROXY_HOPS=1` ·
`NARRATIVE_TRACKING=1` · `NARRATIVE_STATE_TTL=7776000` · `COORDINATION_BASELINE` (unset = unbanded)

All have working defaults; none must be set for the app to boot.
