# Evidence review — coordination is the signal, content is not

**Date:** 2026-09-01 · **Companion artifact:** "The Evidence Reorders the Roadmap"
**Inputs:** Ferrara *Five Myths* (preprints.org, Jun 2026) · Verdolotti et al. arXiv:2608.16601 ·
Gerard et al. WWW'26 (code: Zenodo 18317567) · TellFinder (Uncharted / DARPA MEMEX) ·
EdgeTheory published corpus (9 reports) · vendor + procurement scan

## The finding that reorders everything

Ferrara assembles the **complete** government-attributed archives of seven state campaigns —
**25,076,853 tweets / 9,071 accounts** (Russia, Iran, Venezuela, Bangladesh) — with a **matched organic
baseline** of never-suspended same-country/period accounts, and re-tests five stylised facts under one
pre-registered protocol (BH-FDR, permutation nulls, future-reception placebo, takedown-snapshot
decomposition).

| Myth | Corrected finding | Statistic |
|---|---|---|
| Monolithic troll army | Narratively segregated, thinly staffed desks running national playbooks | ~**27× below** chance null; median **3 hands/desk** vs 5 organic |
| Wins on moral emotion | Moral-contagion law **fails to replicate in any of them**; a meaningless placebo predicts engagement as well | Russia IRR **0.848** vs placebo 1.537 (sign reverses) |
| Manufactures its virality | Reach is **captured, not manufactured** | Internal share **0.10–5.31%** of top-percentile reach |
| Sophisticated optimising adversary | Scripted, not feedback-adaptive; mean-reverting | **9 of 110** cells survive placebo; Galton φ 0.17–0.70, all CIs < 1; ~52% of each shock undone |
| Indistinguishable from real users | Language drifted off the 2016 fingerprint, **but coordination held** | **7–70×** more coordinated than matched organic; replicated in **12 further countries** |

> "The detectable signature has **migrated from language to coordination**: per-account content
> fingerprints age out, while cross-account coordination remains the durable, cross-national marker."

## Corrections to my earlier advice

**1. Framing classification is demoted.** I said lead with framing (0.539 macro-F1 vs persuasion's
0.129). Right about relative difficulty, wrong about priority — moral-emotional content did not predict
engagement in *any* of the seven confirmed campaigns. Framing/stance/persuasion are analyst-facing
*description*, not detection.

**2. A matched organic baseline is now mandatory.** Ferrara: *"on corpora of confirmed manipulation,
baseline-free significance reconstructs the analyst's expectations."* Every coordination number XTag
emits must be stated against ordinary accounts on the same topic and period. Without it the system
confirms whatever the analyst already believes — the relevance-gate failure one level up.

**3. New metric: captured vs manufactured reach.** Real operations self-generate only 0.1–5.3% of
top-percentile reach. Internal-amplification share is cheap to compute (we have X retweeter/quote data),
has a published reference range, and no competitor ships it.

**4. Forward warning to design for.** These operations run scripts. *"An adversary that genuinely
optimized — now feasible with LLMs — would look measurably different… a forward warning, not a present
finding."* Build the harness so an *adaptive* adversary can be synthesised.

## Market reality

| Vendor | Position | Signal |
|---|---|---|
| Cyabra | Only pure-play with audited financials | $7.0M ARR, **going-concern warning** |
| Graphika | Best method in sector, unfunded since 2017, repositioning into fraud/brand | ~$6.1M rev, ~55 staff |
| Logically | **Insolvent**, pre-pack administration Jun 2025 | — |
| Blackbird.AI | Strongest marketing, no published methodology, no prime federal contracts found | $58M raised, 3 Gartner reviews |
| Memetica/Miburo/Pyrra/Storyful | All acquired into consultancies, Microsoft, corp security, media | exited |
| Dataminr | Where the money is — but alerting infrastructure, not narrative analysis | **$317.8M** USAF, Aug 2026 |

Gartner created the Narrative Intelligence category (Jun 2026) and predicts $30bn by 2028. **Twenty
products, nine total customer reviews.**

**The money moved, it didn't vanish.** GEC closed, SIO wound down — but DoD IO/OSINT spend rose and ICE
bought Zignal (Sept 2025). Growth is in **domestic surveillance and corporate reputation**, not
counter-disinformation.

**The opening:** *no vendor publishes accuracy, precision/recall, or a coverage matrix. No independent
benchmark exists.* The differentiator available in 2026 is evidence, not features — and it's the one
thing funded competitors can't copy quickly, because copying means publishing their numbers.

**Pricing:** observable clearing price $90k (Pyrra/Army) to $450k (Zignal/Fiscal Service). $250k ACV
defensible; $1M+ is not.

**Chargeable vs not.** Chargeable: licensed data at scale, SLA/continuity, analyst labour, procurement
and legal cover, persistent cross-platform identity. Not chargeable (weekend projects now): dashboards,
sentiment scores, topic clustering, volume charts, keyword alerts, LLM summarisation.

## EdgeTheory — copy the template, fill the gaps

Rigid report template, worth copying: **Preface** (150–200w, names the three techniques + collection
streams) → **Introduction** (300–600w) → **Key Findings** (3–4 bolded assertions as *general
mechanisms*, numbers inside the paragraph not the headline) → **Narrative Infographics** (the evidence
section) → topic sections → **Conclusion** (no new evidence) → **named Lead Analyst**.
Target **3,000–4,200 words, 10–20 figures** (~1 figure per 200–250 words). Commercial variant swaps
geospatial for *"What This Means for Organizations with X Exposure"*, segmented by buyer function.

Their unit of analysis: *"Sources are the foundational unit — not keywords, not topics."* Sources carry
national/factional/ideological alignment as first-class attributes. A third valid answer alongside
Protagonist's belief and our claim.

**The gaps = the product.** Across nine reports they never state N, date range, source count, or
languages. No confidence language, no alternative hypotheses, no intelligence-gaps section. Every
coordination judgement asserted, not shown; aggregates narrated in prose, never tabulated. Their most
careful phrasing: *"shows characteristics of coordination."*

**XTag's report = same template + five additions:** N and time window on every claim; matched organic
baseline for every coordination number; calibrated confidence; explicit alternative hypotheses (fandom,
breaking news, cross-posting — and why rejected); intelligence gaps. Four of five already exist in our
payload — it's a rendering problem, not a research problem.

## TellFinder — the analyst interface

- **Overview before drill-down.** *"Without this overview, users can not have confidence in the scope of
  the data or understand potential gaps."*
- **Their first attempt failed as ours would:** raw bipartite graph *"unwieldy for end users due to data
  volume."* Fix: **compress highly connected clusters into single entity nodes**. Entity resolution as a
  rendering strategy.
- **Three node types:** entity / attribute / search-result.
- **Expand-on-demand with degree-of-interest** — the seed-and-expand interaction as a UI primitive.
- **Case Files** = evidence baskets you drag entities into, then generate the report. Our cases are
  saved searches; this is the version worth having.
- False-positive sources: obfuscation → "noise and excessive linking"; image similarity → too many valid
  links. Ours will be unresolved URLs and near-duplicate text.

## The harness

**SimSoM** (Verdolotti et al.) — agent-based diffusion model calibrated to real data (GB2 activity via
CMA-ES, bimodal Beta content quality), validated temporally/distributionally/structurally. Ready-made
generator.

**Critical warning:** *"static evaluation significantly overestimates the effectiveness of user bans…
compensatory resharing dampens the expected reduction… static estimates should be read as an upper
bound."* Measuring "we'd have caught 90%" on a frozen corpus is an upper bound, not performance.

**Gerard et al. production split** (code public): Llama-3-70B-Instruct offline / **Gemma-4B-Instruct at
245 posts/sec** streaming; Qwen3-Embedding-0.6B; DP-means λ=0.10; clusters refresh 48h; >94% AUC
predicting narrative emergence using <3% of active users.

**Steal their validation protocol, not their model choices:** BERTScore(claim, source) — 0.82
Llama-3-70B vs 0.76 Gemma-4B; human annotation κ=0.84 over 200 claims at 91.5%; and the
**platform-invariance probe** — a classifier guessing source platform scores 0.67 on raw posts, 0.26 on
extracted claims (0.25 = chance). Run it as a **language**-invariance probe for the multilingual case.

## Revised roadmap

| # | Build | Change |
|---|---|---|
| 1 | Injection harness **+ matched organic baseline** | expanded |
| 2 | Coordination pipeline (co-URL, co-retweet) | confirmed — text similarity is the weakest trace (0.52 AUC) and it's what we count today |
| 3 | **Captured vs manufactured reach** | new |
| 4 | Claim extraction + persistent narratives | unchanged; public reference code now available |
| 5 | Seed-and-expand + case files as evidence baskets | sharpened by TellFinder |
| 6 | **Report generator** (EdgeTheory template + the five additions) | new |
| 7 | Framing / stance / persuasion | **demoted** |

## Overdue decision

The counter-disinformation buyer was dismantled; the budget that grew is domestic surveillance and
corporate reputation. Graphika repositioned into fraud/brand. Zignal sells to ICE. **Babel Street —
which XTag already uses as a source — was named by Amnesty International in August 2025.**
Decide XTag's surveillance-adjacency policy *before* the first government RFP. It is permanent, it
affects hiring, and on current evidence it is the most predictable way this category damages the
companies in it.

## What six independent sources agree on

DARPA 2015 (ML alone insufficient; semi-automated with inspectable reasoning) → INCAS 2021 (analyst
effectiveness in Cohen's d above classifier F1) → Ferrara 2026 (coordination against a baseline; content
ages out) → TellFinder (overview, entity compression, expand-on-demand) → Protagonist and EdgeTheory
(both sell a signed structured assessment; neither sells a score) → the market (every incumbent a black
box, none publish a checkable number).

XTag already has the architecture this points at. **What is missing is a baseline, a measured detection
floor, and a report that ends in a decision.** Buildable in a quarter, and together they would make XTag
the only product in the category that can show its work.
