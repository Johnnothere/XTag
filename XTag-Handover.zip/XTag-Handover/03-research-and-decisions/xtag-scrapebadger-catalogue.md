# ScrapeBadger Social Data Catalogue (for XTag)

**Reviewed:** 2026-09-01 · **Source:** docs.scrapebadger.com (platform overviews, credits-and-pricing, rate-limits, twitter-streams)
**Companion artifact:** ScrapeBadger Social Data Catalogue (published page with full endpoint tables)

## Platform basics
- Base URL `https://scrapebadger.com/v1` · auth header `x-api-key: sb_live_…`
- PAYG **$0.15 / 1,000 credits** (1 credit = $0.00015), min top-up $10, credits never expire, 1,000 free credits, failed requests never charged
- Rate limits: Free 60/min · Basic 300/min · Pro 1,000/min · Enterprise 5,000/min. Headers `X-RateLimit-*`, `Retry-After` on 429
- Subscriptions: Starter/Growth/Pro/Scale (Scale = 13M credits/mo); monthly prices not published
- MCP server `https://mcp.scrapebadger.com/mcp` — 344 tools, 30+ products, OAuth 2.1, no extra cost
- Errors: 401 auth, 402 insufficient credits, 429 rate limit. Cursor paging via `next_cursor`

## Coverage summary

| Platform | Status | Keyword search | Endpoints | Limit |
|---|---|---|---|---|
| X / Twitter | Full | Yes, full advanced-search syntax | 34 REST + 19 stream | Per-item billing |
| TikTok | Full | Yes (video/user/hashtag) | 22 | Ad library EU-only |
| YouTube | Full | Yes + transcripts, live chat | 40 | streams endpoint 15 cr |
| Instagram | Full | Hashtag + top search | 11 | No stories/geo |
| Facebook | Partial | **Global search returning 503** | 16 | Discovery down |
| Reddit | Full | Yes | 22 | 100 items/page |
| LinkedIn | Lookup only | Jobs only — no post/people search | 10 | Need the slug |

**Not covered at all:** Telegram, Bluesky, Threads, Mastodon, Truth Social, VK, Weibo, Douyin, Discord, Twitch, Snapchat, Rumble, Gab. Chinese-language = Baidu search only; Russian = Yandex search only.

## X / Twitter (flagship)
Billing: **1 base credit + 1 credit per item returned** (20-tweet search = 21 credits; 100-item page = 101 cr ≈ $0.015 → ~$0.15 per 1,000 tweets).

- **Tweets (11):** advanced_search (`from:` `to:` `since:` `until:` `min_faves:` `lang:`; query_type Top/Latest/Media; 1–100/page), tweet detail, batch by IDs, replies, retweeters, favoriters, quotes, similar tweets, community notes (`/tweets/tweet/{id}/community_notes` → id, text, status, created_at — status vocabulary undocumented), edit history, article detail
- **Users (11):** by username, by ID, batch by IDs/usernames, user tweets, followers, following, subscriptions, mentions, search users, user articles
- **Lists (3)** · **Communities (3)** · **Trends (2)** — `/twitter/trends/place/{woeid}` returns name, url, query, tweet_count, domain_context (woeid 1 = worldwide, 23424977 US, 23424975 UK) · **Geo (2)** · **Spaces (2, metadata only)**

### Twitter Streams (only push product in the catalogue)
- **Stream Monitors** — up to 100 accounts/key, 100ms poll, fires on tweet/reply/retweet/quote. Credits per account per day: Starter 1–10 = 1,667 ($7.50/mo) · Growth 11–50 = 1,333 ($6.00/mo) · Scale 51–100 = 1,000 ($4.50/mo) · Enterprise 101+ = 833 ($3.75/mo)
- **Filter Rules** — up to 50/key, any advanced-search query, poll 0.1s–24h. Credits/rule/day: Turbo 0.5s = 30,000 ($135/mo) · Fast 5s = 10,000 ($45/mo) · Standard 60s = 1,500 ($6.75/mo) · Relaxed 10min = 500 ($2.25/mo) · Daily = 100 ($0.45/mo)
- Delivery: `wss://scrapebadger.com/v1/twitter/stream` or webhook with HMAC-SHA256. Sub-second latency, 100 results/poll cap, auto-dedup, billed every 60s, auto-pause on `insufficient_credits`
- Warning in docs: new/dormant accounts may be shadow-banned and return nothing — validate before monitoring

## Per-platform credit costs (key endpoints)
- **TikTok** — search/search-users/search-videos/search-hashtags/trending-* 5; hashtag videos, user videos, reposts, comments, comment replies, related, music videos 8; transcript 10; oembed 2; regions 0. `region` param = ISO-3166 alpha-2, automatic proxy routing. Music→videos and reposts are the strongest coordination signals.
- **Instagram** — user 5, user posts 8, media 5, comments 8, comment likers 8, hashtag info 5, hashtag recent 8, search hashtags 2, search top 5, oembed 2, health 0. Responses `{items, count, next_cursor, has_more}` + `X-Credits-Used` header.
- **Facebook** — page/profile 5, page posts 5, group 5, group posts 5, post 5, **post comments 10**, ad library search/detail/pages 5, marketplace 5 (reference 0). Relay paging `end_cursor` → `after`. Dual timestamps `*_utc` and `*_at`. Global search **503**.
- **YouTube** — search/trending/hashtag/home/music 5, autocomplete 1, video detail 10 (batch 10/video), transcript 5 (SRT/VTT/full-text), captions 2, comments + replies 5, live chat 5, related 5, **streams 15**, shorts 5, shorts-by-sound 5, channel endpoints 5 (about/subscriber_count/resolve 2), playlists 5, community posts 5, oembed 1, reference lists 0.
- **Reddit** — cheapest platform, 1–3 credits. search posts/subreddits/users 2, domain posts 2, post 2, comments 3 (depth 0–10), duplicates 3, trending 1, subreddit 2, subreddit posts 2 (hot/new/top/rising), rules/wiki 1, wiki page 3, popular/new subs 1, user 2, user posts/comments 2, moderated 3, trophies 1. Max 100 items/page.
- **LinkedIn** — profile 8, company 6, school 6, post 5, article 5, jobs search 5 (`start` in blocks of 25), job 5, company jobs 5, course 5, geo suggest 2.

## Adjacent sources on the same key
Google Trends (7 endpoints: search, trending now, interest over time, interest by region, related topics/queries, topic autocomplete) · Google News (3) · Google Ads Transparency (4) · Google Scholar (5) · Google other (14: web, images, videos, shorts, Lens, AI Mode, Maps/places/reviews, local pack, autocomplete, patents, finance) · Yandex (4, incl. reverse image) · Baidu (4) · Bing/DuckDuckGo/Yahoo (20) · ChatGPT & Gemini ask + brand visibility (5) · Web scrape `POST /web/scrape` (curl_cffi 1 / browser 5 / windows_chrome 10 credits; anti-bot +5, AI extraction +2; retries free) and `/web/detect`.

`/web/scrape` is the escape hatch for uncovered platforms — HTML + AI-extracted fields, not a structured social schema.

## Cost model — worked examples
| Workload | Credits | Cost |
|---|---|---|
| 1,000 tweets via advanced search (10 × 101) | 1,010 | $0.15 |
| Followers of a 50k-follower account | ~50,000 | $7.50 |
| 1,000 TikTok hashtag pages | 8,000 | $1.20 |
| 1,000 Reddit post searches | 2,000 | $0.30 |
| 1,000 YouTube transcripts | 5,000 | $0.75 |
| 20 filter rules @ 60s, 30 days | 900,000 | $135 |
| 50 monitored X accounts, 30 days (Growth) | 2,000,000 | $300 |
| 100 monitored X accounts, 30 days (Scale) | 3,000,000 | $450 |

**Asymmetry to plan around:** batch collection is near-free (~$150 per million tweets); real-time streaming is where the money goes. One Turbo rule ≈ the cost of pulling 900k tweets on demand.

## Fit against XTag's capability list
**Strong:** early narrative emergence (Google Trends + X trends by WOEID + TikTok/YouTube trending per region) · cross-platform migration (same query across 5 platforms) · coordination detection (X retweeters/quotes/similar, Reddit duplicates + domain posts, TikTok music→videos, YouTube shorts-by-sound) · actor/network mapping (X followers/following/mentions, Reddit moderated subs) · paid amplification (FB Ad Library + EU DSA, TikTok EU ad library, Google Ads Transparency) · framing analysis (transcripts + full comment trees).

**Weak:** real-time alerting is X-only · Community Notes status vocabulary undocumented · Facebook discovery down (503).

**Gaps:** Telegram (the platform most on XTag's original Hezbollah/psy-ops mandate), Threads, Bluesky, Truth Social, VK, Weibo, Douyin.

## Recommendations
1. Use ScrapeBadger as the **discovery and enrichment layer**, not the alerting layer — 6 of 7 platforms are pull-only.
2. Default filter rules to **Standard (60s, $6.75/rule/mo)**; escalate to Fast only inside a declared incident window.
3. Build a dedicated **sound/music-graph collector** (TikTok `music/{id}/videos`, YouTube `shorts/by_sound`) — catches template reuse text search misses.
4. Add **transcript collection** for TikTok (10 cr) and YouTube (5 cr) so video enters the sentiment corpus.
5. **Telegram gap is not closable here** — keep the purpose-built Telegram actor as the #1 addition from the earlier source evaluation.
6. **Verify disputed counts** with a free-tier key: the MCP page claims 39 Instagram / 12 Reddit tools, overviews say 11 / 22; YouTube overview lists 40 endpoints vs 14 in the docs index.
7. The **MCP server** (344 tools, OAuth 2.1, no extra cost) is the fastest route to an analyst-driven prototype before pipeline integration.
