# XTag model assessment — which models to use, and in what order

**Date:** 2026-09-01 · **Method:** three parallel research passes (DARPA programme record; SemEval/CLEF
shared-task proceedings; coordinated-behaviour literature). Every figure below is from a published
leaderboard, paper or programme document.
**Companion artifact:** "XTag Model Assessment" (published page with the full argument).

## Two corrections to the framing

1. **The attached PDF was not the programme.** It is Lewis (2010), a survey of college students'
   attitudes toward social media for PR educators. The pasted text is **DARPA SMISC** (BAA-11-64, 2011).
2. **SMISC is a 2011 target and DARPA moved off it.** The successor, **INCAS** (2021–2025), changed
   two things worth copying: it **dropped counter-messaging entirely** (detect/characterise/track only),
   and it **added population response** (audience segmentation) as a technical area. Its headline metric
   is **analyst effectiveness in Cohen's d**, not classifier F1.

**INCAS does not name "narrative extraction" as a primitive.** Its TA1 indicators are, verbatim:
**Agenda** (what the author wants the reader to believe or do), **Concerns** (wedge issues and
moral/sacred values), **Emotions** (strong sentiment or tone). That is a more tractable decomposition
than "extract the narrative."

No published INCAS evaluation results exist. The solicitation's F-score targets are promised, not
demonstrated. DARPA's page reads "complete" and there is no named successor in the open.

## The model list, triaged

The list is a shared-task results table with OCR damage — which is why it contains clinical-trial
inference and legal argument classification.

| Item | Verdict |
|---|---|
| Multilingual persuasion techniques | Adopt, but far weaker than advertised |
| Multilingual transformer (XLM-R / mDeBERTa) | Adopt — non-negotiable for a 20%-Persian corpus |
| All-MPNet | **Wrong checkpoint — English-only.** Would return confident garbage on Persian/Arabic |
| TF-IDF + sentiment | Keep TF-IDF as a control; replace sentiment with stance |
| **GNNs** | **Do not build** — see below |
| BERT/DeBERTa | Backbones, not capabilities |
| T5-Medical, Mistral-Legal, BETO, "STERHEOSCHOOL", "Sense Defiance", "TransMistral" | Table noise |

## The numbers that change the plan

**Persuasion technique detection is oversold.** SemEval-2023 Task 3 subtask 3, 23 techniques, official
test leaderboard:
- **English macro-F1 of the winning system: 0.129.** Micro is 0.376 and is dominated by two head classes.
- Zero-shot on a genuinely unseen language with an adequate test set (Greek): **0.267 micro**.
- The winning team's own words: their system *"focuses on the majority classes and struggles with
  classifying some of the more scarce persuasion techniques."*
- Domain transfer news → political ad copy costs **~27 F1 points**. News → social will be worse.

**Framing scores 4× better on identical data.** Media Frames taxonomy (14 frames + Other):
**0.539 macro English, 0.660 German**, and zero-shot holds 0.55–0.65 micro where persuasion collapses
to 0.27. It is also the better question — what axis is this contested on, versus which device appears
in span 47.

→ **Lead with framing. Ship persuasion techniques as high-precision analyst evidence on the six head
classes only** (`Loaded_Language`, `Name_Calling-Labeling`, `Doubt`, `Exaggeration-Minimisation`,
`Appeal_to_fear_prejudice`, `Flag_Waving`), never aggregated into a score.

**Winning recipe is dull and reproducible:** XLM-RoBERTa-large, one model, fine-tuned jointly on all
languages at once, per-class thresholds calibrated separately for seen vs unseen languages. Translation
pipelines and per-language models both lost.

**The real blocker is licensing.** Every SemEval persuasion corpus is registration-gated, research-only,
non-redistributable. There is no downloadable multilingual 23-label classifier with weights, licence and
metrics. Annotate our own against the published taxonomy, or license.

**Don't build the GNN.** TwiBot-22 (1M accounts), accuracy: feature-based Hayawi **76.5%**, SGBot 75.1%,
RoBERTa 72.1% — versus RGT **68.2%**, BotRGCN 66.4%, GAT 64.8%, GCN 63.9%. Feature-based gradient
boosting beats every GNN by 7–12 points on the largest benchmark. WWW 2023 best paper: shallow decision
trees reach near-SOTA and high scores are *"attributable to limitations in dataset collection and
labeling rather than sophistication of the tools."* In streaming event detection, plain incremental
clustering beat a GNN method and ran ~6,000× faster (72s vs 5+ days). The current SOTA coordination
papers deliberately use **node2vec + Random Forest**.

## The highest-value change is not a model

`app.py:detect_coordination` is currently
`coord_score = min(100, 8·dupe_pairs + 20·(burst>15) + 5·cross_shared)` — a hand-invented counting rule
carrying the **largest single weight in the threat score (20/100)**.

Five independent groups converged on a classical pipeline that needs no labels, no training, no GPU:

1. Generic schema `object_id, account_id, content_id, timestamp` — one code path for co-URL, co-retweet,
   co-hashtag, co-image-hash and cross-platform.
2. **Canonicalise URLs first** (resolve shorteners, strip UTM/AMP); require ≥5 occurrences; cap frequency
   at the 90th percentile.
3. Bipartite → **TF-IDF** (load-bearing: downweights viral objects, upweights obscure ones) → cosine.
4. Edge filter by **disparity filter** or hypergeometric SVN with FDR — a p-value per edge, not an
   arbitrary percentile.
5. **Fuse traces by simple union.** Weighted fusion was tested and lost.
6. **Prune nodes by eigenvector centrality** (this is where precision comes from), then **Leiden**
   (not Louvain — Louvain can produce internally disconnected communities).
7. Emit a continuous score **plus the evidence**; never a binary label.

Measured trace quality (Luceri et al., WWW 2024, 49M tweets, 6 countries):
**co-URL 0.72 AUC · co-retweet 0.69 · hashtag sequence 0.68 · fast retweet 0.62 · text similarity 0.52.**
Node pruning beats edge filtering by ~42% precision; eigenvector threshold 10⁻² gives **precision >99%**.
Schoch et al.: **74% of astroturfing accounts at ~1% FPR** using co-retweet in a 1-minute window.

**Note: text similarity — what XTag currently counts — is the weakest of the five traces, barely above
chance.** Co-URL and co-retweet are the workhorses and we already collect both.

### The constraint that must shape the product
**Coordination is not inauthenticity.** The largest coordinated clusters in the 2022 US midterms were
K-pop and Taylor Swift fans. Vargas et al.: F1 0.98 on known campaigns, **0.71 on unseen ones**, and
*"Coordination is not a unique phenomenon that only occurs in SIO campaigns."* Breaking news, RSS
cross-posting, activist networks and follow-trains all produce the same signature.

## Narrative identity — solved since 2010, not implemented here

XTag re-derives narratives from scratch every search, so it can say a narrative exists but never that it
**grew**. Greene, Doyle & Cunningham (2010): cluster per window, match each new cluster to the "front"
of every dynamic community by Jaccard at **θ = 0.3**; above → same narrative, below → birth.
Death after 3 unobserved windows; merge/split when a cluster matches ≥2 communities or vice versa;
expansion/contraction at ±10%. Use hybrid similarity (Jaccard on persistent members where available,
centroid cosine where not) with Hungarian one-to-one assignment. Emit **stable UUIDs**.

Two traps: **BERTopic's dynamic topic modelling freezes the topic set** and structurally cannot discover
emergent narratives — use its c-TF-IDF only for labels. **Never put UMAP on the identity path** — since
v0.4 it is multi-threaded and its own docs state results depend on *"race conditions between threads...
over which no control can be had"*; not reproducible even with a seed.

## Embeddings

| Model | Params | Licence | MMTEB | Clustering | Verdict |
|---|---|---|---|---|---|
| Qwen3-Embedding-0.6B | 0.6B | Apache-2.0 | 64.3 | — | Default |
| multilingual-e5-large-instruct | 560M | MIT | 63.2 | 51.5 | Safe |
| BGE-M3 | 568M | MIT | — | — | If sparse+dense wanted |
| jina-embeddings-v3 | 572M | CC BY-NC | 64.4 | 46.7 | **No Hebrew, non-commercial** |
| paraphrase-multilingual-mpnet-base-v2 | 278M | Apache-2.0 | 52.0 | 41.1 | Retire — 128-token cap |

**Persian:** a 124M Persian-specific model (Hakim) scores **73.8 on FaMTEB vs multilingual-e5-large's
64.4** — a 9.4-point gap in favour of the smaller model. The spread *among* multilingual models on
Persian is under one point, so the decision is whether to route Persian to a dedicated model, not which
multilingual one to pick. Given ~20% of the #covid1948 corpus was Persian, route it.

E5 requires the `query:`/`passage:` prefix — omitting it degrades quality silently.

## Build order

1. **Replace the coordination score** with the published pipeline. No labels, no GPU, largest threat-score weight. (`app.py:detect_coordination`)
2. **Narrative identity across time** — embeddings → incremental clustering → Greene front-matching → stable UUIDs, persisted to Supabase. Makes "velocity" mean something.
3. **Evaluation harness — 300 labelled documents** from our own corpus: on-topic, frame, stance, coordination membership. Gates everything below.
4. **Framing classification** (mDeBERTa-v3 / XLM-R-large, 14 Media Frames labels, joint multilingual fine-tune).
5. **Stance replacing sentiment** for claim work — a typed edge (author → target, support/oppose) composes into the entity graph; a sentiment scalar does not. Cold-start with NLI-as-stance on `mDeBERTa-v3-base-xnli-multilingual` (MIT).
6. **Persuasion techniques, head classes only**, as highlighted spans for analysts.
7. **Cross-platform migration with a statistical test** — ≥24h lead + ≥10 posts, then transfer-entropy permutation test. In the one published study, **1,552 apparent migrations → 238 survived the test (~85% unsupported)**. Report raw influence *and* per-post efficiency.

## Two things to design around

**The ground truth is gone.** The Twitter/X Information Operations Archive (115,474 accounts,
57 operations) was deleted after the acquisition. Circulating copies are mirrors of unclear provenance.
There is also circularity: those labels came from the platform's own detectors, so validating against
them partly confirms itself. The one independent validation set in the literature came from South Korean
court records — precisely because that campaign escaped Twitter's detection.

**Nobody has solved effect measurement.** SMISC goal 3 and INCAS TA2 both name it; neither demonstrated
it. OpenAI's own October 2025 report: a Russia-origin network whose core account *"only had 172
followers"*; a China-origin operation where *"most of the posts received minimal or no engagements."*
XTag's threat score should keep saying it measures signal, not impact.

**And the oldest finding still holds.** DARPA's 2015 Twitter Bot Challenge — the most concrete thing
SMISC produced — concluded **"machine learning by itself would be inadequate"**, and that
*"interfaces that easily explain why a particular account is considered a bot are particularly
important."* INCAS made that structural six years later. XTag's explainable factor breakdown is already
the right architecture; the work is making each factor worth explaining.
