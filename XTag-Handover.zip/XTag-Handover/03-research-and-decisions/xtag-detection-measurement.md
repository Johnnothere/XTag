# XTag — coordination detection, measured

**Date:** 2026-09-03 · **Reproduce:** `python harness.py` · **Tests:** `bash tests/run.sh` (199 checks)
**New files:** `harness.py` (red-team injection harness), `coordination.py` (rebuilt detector), `tests/`

Until now every claim about XTag's coordination detection was an assertion. `detect_coordination`
returned a number between 0 and 100 and nobody could say what it should have been, because on a real
corpus nobody knows the answer. This is the fix DARPA's SMISC programme used: inject synthetic
campaigns with known ground truth into real-shaped traffic and score what comes back.

---

## The harness

Six campaign types, each isolating one evasion the old implementation invites, injected into 400
organic documents across 220 accounts:

| Campaign | What it tests |
|---|---|
| `copypasta` | identical text across platforms — the textbook case the detector was built for |
| `same_platform` | identical text on ONE platform — skipped by construction (`if da.platform == db.platform: continue`) |
| `paraphrase` | one claim, many wordings — costs the operator one LLM call per post |
| `url_variants` | same destination behind per-post `utm_` parameters |
| `slow_burn` | identical text spread over a week instead of half an hour |
| `adaptive` | every evasion at once, plus engagement kept low — an adversary who has read the code |

Scored with the SMISC Bot Challenge formula, `Hits − 0.25·Misses + Speed`, with speed capped at one
point because a fast wrong answer is still wrong.

**The harness is itself tested** (`tests/test_harness.py`, 30 checks): an oracle detector must score
100%, a null detector 0%, and a flag-everything detector must get full recall but be punished on
precision. A harness that flatters is worse than none.

## What the old detector actually did

| Campaign (n=32) | recall | precision | score |
|---|---|---|---|
| copypasta | **0%** | 0% | 60 |
| same_platform | **0%** | 0% | 40 |
| paraphrase | **0%** | 0% | 60 |
| url_variants | **0%** | 0% | 60 |
| slow_burn | **0%** | 0% | 40 |
| adaptive | **0%** | 0% | 40 |

Zero recall on all six, at every size from 4 to 64 documents. **Breaking point: never detected.**

Three mechanisms, each confirmed by direct instrumentation rather than inferred:

1. **It looked where campaigns are not.** `detect_coordination` ran on `_top_docs(300)` — ranked by
   engagement — and then compared only the first 100. Campaign accounts are low-engagement by
   definition; manufacturing reach they do not have is the entire point. On a 64-post identical-text
   campaign, **0 of 64 campaign documents entered the comparison window.**
2. **Recall fell as the campaign grew.** Forcing the campaign to maximum engagement so it could not be
   ranked out gave 75% recall at 8 posts and **9% at 64** — because `examples: dupe_pairs[:5]` caps the
   cited documents at five pairs regardless of scale. A bigger operation got a lower score.
3. **It fired on nothing.** Across five seeds of pure organic traffic with no campaign injected at all,
   the score ranged **0–96**, banding organic news chatter as **"high risk"**. The thresholds
   (>60 high, >25 medium) were calibrated against nothing.

## The rebuild — `coordination.py`

Three design changes, each forced by one of those findings:

- **Actors, not documents.** Coordination is a property of accounts acting together. The unit is the
  actor–trait bipartite graph (Pacheco et al.), projected to actor–actor TF-IDF cosine via an inverted
  index, disparity-filtered, then clustered.
- **Traits, not text.** Luceri et al. trace AUCs: co-URL **0.72**, co-hashtag, co-timing, text
  similarity **0.52**. Text was the only signal the old detector used, and it is the weakest and the
  easiest to defeat. URLs are canonicalised first — tracking parameters stripped, host normalised — so
  `?utm_source=` no longer hides a shared destination.
- **The full corpus**, not the top 300 by engagement.

### One finding worth keeping

The Serrano disparity filter *removed the campaign*. It keeps edges that stand out against a node's own
weight distribution — and a coordinated clique is the one structure where that inverts: 16 accounts
posting identical text form a near-complete uniform-weight clique, so every edge is exactly average and
nothing is exceptional. It silently discarded 120 campaign pairs **at cosine 1.0**. An edge now survives
if it is locally exceptional **or** carries high absolute weight, because two accounts with identical
trait vectors are evidence regardless of how uniform their neighbourhood is.

## Result

| Campaign (n=32) | old recall | new recall | new precision |
|---|---|---|---|
| copypasta | 0% | **100%** | 97% |
| same_platform | 0% | **100%** | 97% |
| paraphrase | 0% | **100%** | 97% |
| url_variants | 0% | **100%** | 100% |
| slow_burn | 0% | **100%** | 100% |
| adaptive | 0% | **100%** | 100% |

Pure organic, five seeds: old **0–96, banded high/medium**; new **0, 0, 0, 0, 0**.
Breaking point: old never; new **8 documents** for every campaign type, 4 for two of them.

**Known limit, stated rather than hidden:** the adaptive campaign at 8 documents (8 accounts, one post
each, four hosts) scores 0% — below the three-actor minimum cluster size. A small, patient, well-funded
operation remains invisible, and no amount of tuning the current traits changes that; it needs
co-engagement data XTag does not collect yet.

## Two corrections I made to my own work

- **My harness had the flaw I criticised in the detector.** `flagged_urls()` read only the cited
  `examples`, so it scored the new detector at 9% recall on a campaign it had actually flagged 64 of 64
  documents of. The citation cap belongs in the UI, never in the measurement.
- **My first organic generator was itself coordinated.** Built from ten fixed phrases, it produced
  traffic that genuinely repeated itself, and the new detector "false-alarmed" at 98 on it. Grading
  against a rigged corpus measures nothing. Organic is now composed from ~17×16×14×9×5×5 combinations:
  400 distinct titles, ~6% of pairs sharing an incidental 5-gram, which is what real coverage looks like.

## Also fixed — wire syndication (P4, was a confirmed defect)

GDELT sets `excerpt == title` and `author == the publishing domain`, so a Reuters story carried by six
outlets arrived as "six identical texts from six distinct authors" — the exact signature
`detect_inauthenticity` treats as high-severity amplification. Measured before: **score 26, severity
HIGH**, feeding info-integrity at weight 45.

| corpus | before | after |
|---|---|---|
| 6 syndicated wire stories | 26 · **high** | 5 · low, reported as `wire_syndication` / **info** |
| 6 sock puppets, same text | 26 · high | 26 · **high** (unchanged — correctly flagged) |
| both together | conflated | sock puppets flagged, syndication noted separately |

Syndication is normal, attributable publishing. Reporting it as an operation wastes the analyst's
attention and makes every genuine finding less believable.

## The band, and why there often isn't one

`coordination.detect()` returns **`risk: "unbanded"`** unless a matched organic baseline is configured
(`COORDINATION_BASELINE`). This is deliberate. Ferrara's cross-campaign work puts confirmed operations
at **7–70× a matched baseline**; a corpus at 1.3× is a fandom, a breaking-news event, or a wire story —
all of which look coordinated to an absolute threshold because, in the ordinary sense, they are. The
harness showed exactly this failure in the old thresholds. A confident wrong band is worse than an
honest missing one, so the module says what it is missing instead of guessing. `harness.baseline_ratio()`
is how you compute the number to set.

## Next

Run `harness.baseline_ratio()` against corpora representative of real XTag queries and set
`COORDINATION_BASELINE`, which turns `unbanded` into a defensible band. Then P5: claim extraction and
Greene narrative tracking.
