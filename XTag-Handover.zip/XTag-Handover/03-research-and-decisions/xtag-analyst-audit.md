# XTag — law-enforcement analyst audit (live platform) — FIXED AND VERIFIED LIVE

Audit observed 05 Sep 2026 on `xtag.up.railway.app`, query "Hezbollah".
Fixes deployed and re-verified live 07 Sep 2026.
Artifact write-up: https://claude.ai/code/artifact/8c211da2-e06f-4ddf-b14f-b46b8c68fe03

Suite: **662 checks, 0 failures** (was 587 + 2 stale). New `tests/test_ui_audit.mjs` (59 checks)
covers the render path — the class of defect the Python suites structurally cannot see and which
reached production twice.

## Confirmed working on the live re-run (07 Sep)

| Ref | Before | After (read off the live page) |
|---|---|---|
| D1 | 365 "narratives" labelled with news headlines | **8 narratives tracked**, real frames: "Israeli military operations against Hezbollah" (28), "Hezbollah drone and missile attacks on Israel" (28), "Israeli sabotage operations targeting Hezbollah devices" (17) |
| U1 | `CONFIDENCE 94.5` | `CONFIDENCE 49`, whole number, each gate named |
| U7 | `OPERATIONAL 73.8 HIGH` | `OPERATIONAL — not assessed` |
| U2 | Top hit = 2008 Zohan comedy clip | Top hit = news from 8 minutes ago |
| M3 | Language table, unjudged | Red banner: "Collection gap — this corpus is 98% English. The query was issued in Persian and Hebrew and returned almost nothing" |
| U6 | Arrow chain across 16.4y | "This is archive depth, not a propagation chain. These documents span 14.7y…" |
| D6 | 9 events, ~5 incidents | 7 events; pager + walkie-talkie merged into one incident carrying both quotes |
| D4 | Brief said "Moderate", block said unbanded | Brief now: "Raw magnitude 6/100, unbanded… cannot be assigned a severity descriptor" |
| U8 | `# INTELLIGENCE BRIEF: HEZBOLLAH` with literal hash | Clean labelled sections |
| M7 | 56 signals counted, 1 cluster, no explanation | "49 account pairs shared at least one behavioural trait. 10 survived the disparity filter (39 did not), forming 1 cluster" |
| D2 | Tracked list restated as event feed | Feed suppressed on first observation |
| D7 | "365 / 365narratives / 365new" | Count printed once |
| M9 | Inert entity tallies | "Click one to filter the evidence grid" |

## Found ON the live re-run and fixed (second batch)

- **One number wearing two bands.** `findingConfidence()` banded confidence on its own thresholds
  (80/55/30) while `intel.py` bands on 70/45. They agreed by luck for most of the range; at 49 they
  did not, and the page printed "Low" in the finding and "moderate" in the assessment for the same
  number. The scorer now owns the band; the frontend reads `confidence_band`.
- D7 residual: the section badge and the strip both printed the count. Badge removed.
- M3 copy: a two-language list read "Persian, Hebrew and returned" — now "Persian and Hebrew".
- The phase-1 note said "the evidence on the right" below 860px, where there is no right pane.

## CORRECTION — M1 was an instrument artefact, not a product defect

The audit reported the Filter control as dead (two clicks, no panel) and ranked it P0. **That was
almost certainly wrong.** On the live re-run, clicking the theme toggle — a control that
unquestionably works — also produced nothing, and typing into the search box did not land either.
The browser pane is not delivering synthetic clicks to this page. Nothing that was clicked through
it responded; only URL navigation (`?q=`) worked.

A Playwright reproduction against the real template confirms the JS path is correct: a dispatched
click flips `aria-expanded` to true, adds `.show`, and computes to `display:block`, and toggles back
cleanly on a second click.

**Do not trust "control X is dead" findings gathered through the browser pane on this app without a
second, independent confirmation.** Ask Tej to click it himself.

What was changed under M1 still stands on its own merits:
- `.grid-toolbar` had `z-index:50` with a code comment calling it load-bearing against result cards
  swallowing toolbar clicks — but the element was `position:static`, where **z-index does nothing**.
  It now has `position:relative`, so the existing intent finally applies. This is a real latent bug.
- The outside-click closer and the `[data-act]` dispatcher are both bound to `document`;
  `stopPropagation` does not stop a same-node sibling, so behaviour depended on registration order.
  The closer now returns early on any `[data-act]` click.
- Date bands extended to 90d / 1y with live counts. The corpus spans 14–16 years and topped out at
  "Last 30 days" — a genuine gap regardless of the button question.

## Still open

- **M4 — sentiment measures topic valence, not stance.** A Hezbollah recruitment video and an IDF
  casualty report both score strongly negative because both are about killing. The anchor machinery
  in `embeddings.py` is the right mechanism; the anchors must become *stance* anchors. Real
  modelling work.
- **No embedding backend configured in production** — the live run reports "Narratives were grouped
  on wording, not meaning". Set `VOYAGE_API_KEY` or `OPENAI_API_KEY`.
- **12 sources reported failed** on the live run (bluesky, facebook, gdelt, gnews, instagram,
  linkedin, notebooklm, pinterest, threads, tumblr, x, youtube) while YouTube documents are in the
  corpus — the failure reporting conflates partial failure with total failure. Worth a look.
- `COORDINATION_BASELINE` still unset — needs 4–6 representative queries through
  `harness.baseline_ratio()`.
- Per-claim source citation inside the brief prose (M8 is done at narrative level only).
