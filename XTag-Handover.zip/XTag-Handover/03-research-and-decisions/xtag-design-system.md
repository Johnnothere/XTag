# XTag design system v3 — "sovereign glass"

**Date:** 2026-08-30 · **Lives in:** `templates/index.html`, the single `<style>` block · **Status:** shipped to the local repo, not committed to git

## The rule the whole system rests on

Apple's Liquid Glass is a **layer**, not a style. From the HIG: *"Liquid Glass applies to the topmost layer of the interface, where you define your navigation."* Apple is equally explicit about the inverse — making a table glass *"would make it compete with other elements and muddy the hierarchy"* — and about never stacking glass on glass: elements sitting on a glass surface get *"fills, transparency, and vibrancy"*, not their own material.

XTag's previous stylesheet glassed the data: stat tiles, cluster cards, entity chips, relationship rows, hero cards, the threat card and the follow-up block all carried `backdrop-filter`. That is the single change with the largest effect on how the product now reads.

| Layer | Material | Elements |
|---|---|---|
| Functional (floats) | Glass — blur 22px, saturate 180%, brightness 1.06, specular rim | rail, top bar, grid toolbar, filter/sort popovers, watchlist sheet, modal, loader, entity-map toolbar and dossier |
| Content (is the evidence) | Opaque `--surface` + 1px hairline | stat tiles, cluster cards, entity chips and rows, relationship list, threat/risk card, result cards, timeline, geography, follow-up |

**The edge is the effect.** Liquid Glass reads as glass because it bends light at its rim — Apple calls this *lensing* — not because it blurs. A blur on its own is 2020 glassmorphism. Every `.glass` surface carries an inset top highlight, a weaker bottom bounce and side rims via a single `::before`. `.glass--deep` deepens the cast shadow for larger panels, matching Apple's rule that bigger glass behaves like thicker material.

**Transparency is set by `background` alpha, never by the filter.** That is what makes one token swap turn the entire system solid.

## Tokens

- **Ground** — near-black with a slight blue bias (`#06070a` → `#1a1f29`), chosen against the warm ember accent rather than defaulting to `#000`.
- **Ink** — `--ink3` was `#55556e`, measuring **2.6:1** on the panel colour while carrying nearly every caption in the product. It is now `#7f8797`, **4.6:1**. `--ink4` exists for decoration and is never used for text.
- **Accent** stays XTag's ember `#e05c28`. Semantic hues are severity-locked: one hue means one severity anywhere on the page.
- **Type** — Instrument Serif for the wordmark and dossier names only; Inter for everything else; JetBrains Mono for every figure, with `tabular-nums`. Tracking goes negative as size rises (`-0.034em` at display) and positive at caption sizes — the detail that separates a real Apple-family ramp from an imitation. Weights stay Regular→Bold; Apple explicitly says avoid Thin and Light, and thin weights on glass are the fastest route to illegibility.
- **Radii are concentric** — `inner = outer − padding`. Capsules for controls, concentric rounded rectangles for panels.
- **Spacing** — 4pt grid, `--s1`…`--s16`.
- **Motion** — three durations, two easings, all tokenised. Ambient motion is slow and rare.

## Accessibility

Three routes converge on the same token override:

1. `@media (prefers-reduced-transparency: reduce)` — Chromium only today.
2. **A user-facing "Reduce transparency" control in the top bar.** Safari does not expose the OS setting to CSS at all, and this audience is Apple-heavy. Apple itself shipped exactly this toggle in iOS 26.1 after the legibility complaints. State persists in `localStorage`.
3. `@media (prefers-contrast: more)` — near-opaque surfaces with a high-contrast border, matching Apple's own Increase Contrast behaviour.

Plus `forced-colors: active` handling, a global `prefers-reduced-motion` block, one visible focus ring that is never removed, `.sr-only`, 44px targets under `@media (pointer:coarse)`, and a print stylesheet — the report is evidence and has to survive a printer.

Section headers are title case, not all-caps: Apple moved lists and forms off all-caps in the 2025 refresh, and caps at 10px was the least legible thing in a dense report.

## What the criticism taught us

Liquid Glass was widely criticised for legibility (NN/g: *"anything placed on top of something else becomes harder to see"*), and Apple oscillated across betas 2–4 before settling less transparent than it started. XTag is the worst-case context for the material: dense numerics, alert states, long operator sessions, consequential decisions. The posture adopted is: **borrow the material's optical language for the chrome, and none of its ambiguity for the data.**

## Layout

Two states, not one. **Landing** is full-bleed editorial — display type at up to 124px, the three capabilities, suggestion chips, nothing else. **Workspace** appears only once there is evidence: report panel left, evidence grid right. The mode tabs no longer disappear below 860px (they used to, which made the Entities and Timeline views — including the entity map — unreachable on a narrow window).
