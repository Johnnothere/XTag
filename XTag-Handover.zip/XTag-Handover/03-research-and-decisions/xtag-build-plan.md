# XTag build plan — 103s → 5s, plus the four defensibility changes

**Date:** 2026-09-01 · **Companion artifact:** "XTag Build Plan"
**Design:** current UI is approved and stays. No visual work in this plan.

## Why search takes 103 seconds

`_run_full_search` is a sequential chain. Each stage waits for all of the previous one. Four of the five
do not need to be on the critical path.

| Stage | Est. | Cap in code |
|---|---|---|
| Collection fan-out | ~35s | `SEARCH_POOL_TIMEOUT=240` (one pool timeout, no per-source deadline) |
| Relevance gate | ~3s | contains a blocking Claude call via `expand_query` |
| Language + translate | ~12s | `enrich_languages` translates for **display only** |
| Sentiment | ~18s | `CLAUDE_SENTIMENT_BATCH=120` + `BABEL_BUDGET=12` |
| Analysis pool | ~25s | `ANALYSIS_TIMEOUT=70` × narratives/entities/events |
| **GDELT snapshot** | ~10s | **`GDELT_ANALYTICS_BUDGET=110`, runs LAST, sequentially** |

Other relevant caps: `MAX_PAGES=10`, `MAX_RESULTS_PER_SOURCE=500`, `GDELT_ARTICLE_WINDOWS=3`,
`GDELT_MIN_INTERVAL=2.0`.

**The caps are facts from the code; the split between stages is estimated — hence sprint 0 is
instrumentation.**

**Honest constraint:** three Claude calls over 160 documents cannot finish in 10s. The way to hit the
number is to make phase 1 complete and useful on its own, and stream phase 2.

## Speed moves, by payoff

| # | Change | Saving | Files |
|---|---|---|---|
| **S1** | **Start GDELT snapshot at t=0**, concurrent with collection. It only needs the query string and nothing before it consumes it — yet it runs last with a 110s budget. ~5 lines. | −10 to −60s | `app.py:_run_full_search` |
| **S2** | Per-source **4s hard deadline** (on the HTTP call *and* the future), replacing the single 240s pool timeout. Slow sources degrade into a visible gap, which the UI already renders. | −20 to −30s | `app.py`, every `search_*` |
| **S3** | Collect less: `MAX_PAGES` 10→2, `MAX_RESULTS_PER_SOURCE` 500→150, GDELT windows 3→1 for interactive. On #covid1948, 530 collected → 114 kept. Keep deep settings for watchlist. | −10 to −20s | constants, `gdelt.ARTICLE_WINDOWS` |
| **S4** | **No LLM in the hot path.** `expand_query`'s Claude fallback sits inside the relevance gate; `enrich_languages` translates for display before anything needs it. Precompute expansions; make translation lazy/per-card. | −15s | `expand_query`, `enrich_languages`, `index.html` |
| **S5** | **Two-phase response over SSE.** Phase 1 = collection, relevance, aggregates, coordination, assessment (all arithmetic). Phase 2 = sentiment, claims, narratives, entities, events. | architecture | `/api/search`, `doSearch` |
| **S6** | **Narratives: LLM → local embeddings.** Claim extraction → `Qwen3-Embedding-0.6B` → DP-means → Greene front-matching. Gerard et al. stream at 245 posts/sec; code public (Zenodo 18317567). Speed fix and correctness fix are the same change. | −25s | new `narrative.py` |
| **S7** | Sentiment: Claude → local multilingual classifier, batched. Content signal is weak per Ferrara, so this is not where seconds should go. | −18s | `attach_sentiment` |
| **S8** | Precompute tracked queries — watchlist runs already exist; write full payloads to cache. | → <1s | `_run_one_subscription` |

## Capability changes (from the knowledge bank)

**C1 — Matched organic baseline.** Every coordination number stated against ordinary accounts on the
same topic/period. Retain a control set of in-corpus accounts *not* in any detected cluster, compute the
same statistics, report the ratio. Ferrara's operations sit **7–70×** above baseline; a cluster at 1.3×
is a fandom. Without it, *"baseline-free significance reconstructs the analyst's expectations."*
→ new `coordination.py`, `intel.py:score_threat`

**C2 — Real coordination detection.** Replace
`coord_score = min(100, 8·dupe_pairs + 20·(burst>15) + 5·cross_shared)` — hand-invented, largest single
weight (20/100) — with: generic `(object_id, account_id, content_id, timestamp)` schema → canonicalised
URLs → bipartite → TF-IDF → cosine → disparity filter → eigenvector-centrality pruning → Leiden.
Co-URL **0.72 AUC**, co-retweet 0.69, text similarity (what we count today) **0.52**.
→ new `coordination.py`, `app.py:detect_coordination`

**C3 — Captured vs manufactured reach.** Real operations self-generate only **0.1–5.3%** of
top-percentile reach. Compute internal- vs external-amplification share per narrative. Cheap,
evidential, unpublished by any competitor.
→ `coordination.py`, new `intel.py` factor

**C4 — Injection harness.** Synthesise a campaign (N accounts, co-share window, URL overlap, organic
cover, duration), inject into a real corpus, score `Hits − 0.25·Misses + Speed`. Sweep to the breaking
point. Cautions: static evaluation on a frozen corpus is an **upper bound** (SimSoM: compensatory
behaviour dampens real effects); also synthesise an **adaptive** adversary, since real ops run scripts
and nobody has tested against an optimising one.
→ new `harness/`

## Sprints

| Sprint | Length | Content | Ships |
|---|---|---|---|
| **0** | 1–2 days | Per-stage timing in the payload, then S1–S4 | 103s → ~25–35s + a real breakdown |
| **1** | 3–5 days | S5 two-phase response | **First paint ≤ 5s** |
| **2** | 1 week | C4 harness, then C1 baseline | A stated detection floor; control set on every number |
| **3** | 1–2 weeks | C2 coordination, C3 reach — measured against the harness at each step | Largest threat-score weight replaced with a published method |
| **4** | 2 weeks | S6 claims + persistent narratives | "N-2871, first seen 14 May, +34% this week"; full result ~10s |

**Deliberately parked:** framing / stance / persuasion classification (moral-emotional content failed to
predict engagement in *any* of seven confirmed campaigns — worth building as analyst description later,
not as detection); GNNs (feature-based gradient boosting beats every GNN by 7–12 points on TwiBot-22);
anything needing labelled training data we don't have.

## Open decisions

1. **Where does phase-2 compute run?** Railway CPU worker (flat cost, fine for our volumes) vs hosted
   inference (faster to stand up). Decides sprint 4's shape.
2. **Is a 4s source deadline acceptable?** It will visibly drop GDELT and Telegram on some queries. The
   alternative is 8s and a slower floor.
3. **Does phase 2 block the case save?** Recommend saving at phase 1 and marking it partial.

None block sprint 0.
