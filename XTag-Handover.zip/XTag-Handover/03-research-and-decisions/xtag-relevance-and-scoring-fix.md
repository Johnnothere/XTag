# XTag Pass A — relevance gate, stratified sampling, source fixes

**Date:** 2026-09-01 · **Status:** written to `~/Desktop/XTag`. **Not committed, not pushed.**
**Files:** `relevance.py` (new, 320 lines), `app.py`, `intel.py`, `gdelt.py`, `README.md`

## The measurement that started this

`GET https://xtag.up.railway.app/api/search?q=%23covid1948` — 103s, 530 documents:

| Measure | Value |
|---|---|
| Documents containing no form of the query at all | **389 / 530 — 73.4%** |
| Exact `covid1948` matches | 94 — 17.7% |
| YouTube's share | **450 / 530 — 85%** |
| Threat / Confidence | 36.9 "elevated" · **94.5 "high"** |
| Broken sources | tiktok **422**, podcasts 401, bluesky no auth |
| Zero-result sources | reddit, telegram, gdelt, state_media, linkedin, threads, pinterest, tumblr |

**Root cause: no relevance check existed anywhere in the pipeline.** `search_youtube` paged up to
`MAX_PAGES × 50` and kept whatever YouTube's ranker returned; after the real `COVID-1948` hits it
degraded into generic COVID-19 vaccine videos. Everything flowed into sentiment, narratives, entities,
coordination and `intel.assess` unchecked.

Four reported symptoms, one bug:
- **Wrong results** — no gate; `gdelt._build_query` only quoted multi-word input, so a fused token went
  to full-text search bare.
- **"Moderate" threat** — real signal was 18% of a 73%-noise corpus, diluting every ratio-based factor.
- **No mention of the protests** — `_top_docs` sorted the whole corpus by engagement and took 160.
  450 high-view YouTube videos monopolised the prompt: the analysis prompt was **43 YouTube + 17 X and
  nothing else**. The Persian X posts and the DFRLab / Jerusalem Post reporting never reached the model.
- **Confidence 94.5** — `intel.py` derives confidence from `n_docs`. 530 junk documents produce high
  confidence. **Noise does not merely add error; it certifies it.**

The scoring layer was never the problem. `intel.py` already computes every score from weighted `Factor`
objects carrying score, weight, `contribution_pct`, availability, detail and reason, and every risk
dimension already ships a plain-English `rationale`. The frontend renders almost none of it.

## What was built

### `relevance.py`
**Fused tokens do not decompose.** `#covid1948` is one identifier, not `covid` AND `1948`.

Matching expands the *query* into plausible written surface forms and tests each against the normalised
document under word boundaries — never by stripping separators from both sides and substring-testing,
which is wrong in the silent direction (with separators gone, `covid19` is a prefix of `covid1948`).

- Folds Turkish dotted İ (`#COVİD1948`, present in the live data), Arabic-Indic and Persian digits, ZWNJ
- Recovers camelCase boundaries: `#QudsDay2020` → `qudsday2020`, `qudsday 2020`, `quds day2020`, `quds day 2020`
- Tiers: exact 1.00 · cross-lingual expansion 0.65 · all-terms-scattered 0.45 · unverified 0.40 · no match 0.00
- `LENIENT_SOURCES` (google, gnews, gdelt, academic, state_media, serpapi, notebooklm) hold only a
  snippet of a longer document, so a non-match is admitted at 0.40, capped at 12/source. YouTube and
  Hacker News are excluded — both were measured *degrading* the query rather than matching it.
- **Dropping is not deleting**: up to 20 rejected docs per platform stay on the group as `filtered` with
  their rejection reason; the payload carries a `relevance` report. `?relevance=off` returns the raw corpus.

### Other changes
- `_top_docs` round-robins across platforms, best-first within each
- `extract_real_world_events` — new analysis stage: protests, violence, arrests, official acts, platform
  enforcement, published attributions. Returns `[]` when unevidenced; each event carries a quoted phrase.
- TikTok 422 fixed: the endpoint takes `keyword`, was being sent `query`. It had been returning nothing.
- Reddit: `return official` fired on an *empty* result, so the ScrapeBadger fallback was unreachable
  exactly when needed
- Telegram matched a raw lowercase substring; now uses the relevance spec
- Instagram: real hashtag feed (`/instagram/hashtags/{tag}/recent`) replacing site-restricted Google
- X: added a `Latest` pass — `Top` alone capped at 19
- TikTok: hashtag feed alongside keyword search; `TIKTOK_REGION` now configurable (was hardcoded US)
- `gdelt._build_query` quotes fused tokens
- `intel.py`: corpus-purity caveat, relevance fingerprint in the score's `inputs` for reproducibility

## Verified result

| | Before | After |
|---|---|---|
| Corpus | 530 docs, 73% noise | **114 docs, 78.5% of collection dropped** |
| YouTube share | 450 (85%) | 65 |
| Hacker News | 20 COVID-19 stories | 0 |
| Analysis prompt | youtube 43, x 17 | **8 platforms: youtube 15, x 15, google 9, instagram 8, gnews 6, academic 3, facebook 2, mastodon 2** |

Evidence now reaching the model: the DFRLab attribution ("Iranian Social Media Campaign Promoted
Anti-Israel…"), the Jerusalem Post write-up, the Quds Day / Nakba72 Instagram posts, and
"Covid-1948 Short Film ~ Pro-Palestine protest against Israel erupt all over the world" — the protest
evidence that was missing.

Negative controls hold: query `covid19` does not match `#covid1948` documents, and vice versa;
`#Nakba72` does not match "Nakba 71".

## New env vars
`RELEVANCE_MIN` (0.35) · `RELEVANCE_AUDIT_SAMPLE` (20) · `TIKTOK_REGION` (US)

**Config gaps, not code gaps:** `BLUESKY_IDENTIFIER` / `BLUESKY_APP_PASSWORD` and
`PODCASTINDEX_KEY` / `PODCASTINDEX_SECRET` are unset — that is why those two sources report zero.

## Open
- Pass B (UI): render the `factors` and `rationale` the payload already carries; sessions/history via
  IndexedDB; filter & sort; entity-map source backlinks; timeline rebuild.
- **Commit and push are manual.** The device bridge reads and writes `~/Desktop/XTag` but its shell
  cannot mount the folder, so no `git` command can run from a Cowork session.
- The gate trades recall for precision by design. If a real query is over-filtered, lower
  `RELEVANCE_MIN` rather than removing the gate; `?relevance=off` and the `filtered` samples make it checkable.
