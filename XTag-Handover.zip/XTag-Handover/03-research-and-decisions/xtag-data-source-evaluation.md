# XTag Data-Source Evaluation: 14 Scraping/API Tools vs. Live Stack

**Date:** 2026-08-30
**Method:** Live XTag deployment (`xtag.up.railway.app`) was probed directly — `/api/status` returns the actual enabled data-source flags, and the frontend bundle was inspected for the platform list — rather than relying on assumptions.

## 1. What XTag is currently running

`GET /api/status` on the live app returns:

```json
"sources": {
  "academic": true, "anthropic": true, "babelstreet": true, "bluesky": false,
  "gdelt": true, "notebooklm": true, "podcast_index": false, "scrapebadger": true,
  "serpapi": true, "state_media": true, "telegram": true, "youtube": true
}
"state_media_feeds": 17, "telegram_channels": 23
```

| Source | Role in XTag | Notes |
|---|---|---|
| **Babel Street** | Primary social/threat-intel backbone | Enterprise OSINT platform used by police/DoD-adjacent orgs. 200+ languages, PAI+CAI, deep/dark web, mobile telemetry, entity/network graphing, built-in sentiment. Quote-only pricing (not public). |
| **ScrapeBadger** | General-purpose scraping layer | Twitter/X (37+ endpoints), Reddit, Instagram, TikTok, Facebook, LinkedIn, YouTube, Google (18 sub-APIs incl. Scholar/News), e-commerce, LLM interfaces. $0.15/1,000 credits, ~1 credit/request. Also exists as an **Apify actor** (`apify.com/scrape.badger`). |
| **GDELT** | Global event/news backbone | Free, event-coded worldwide news monitoring. |
| **SerpAPI** | Search/News/Scholar layer | Almost certainly also backs the `academic` flag (Google Scholar). |
| **Telegram** (custom) | 23 channels tracked | Not ScrapeBadger — ScrapeBadger's list doesn't include Telegram, so this is a bespoke integration (bot/Telethon-style) of unknown depth. |
| **State media** | 17 curated feeds | Bespoke RSS/feed list, not a vendor. |
| **YouTube** | Direct | Likely YouTube Data API, separate from ScrapeBadger's YouTube endpoint. |
| **NotebookLM / Anthropic** | Synthesis, not ingestion | Used for the narrative-writing/report layer, not data collection. |
| **Bluesky, Podcast Index** | Flagged `false` | Built but not switched on — real open gaps. |

**Bottom line on the baseline:** XTag already has a premium enterprise OSINT platform (Babel Street) plus a broad general-purpose scraper (ScrapeBadger) covering X/Twitter, Reddit, Instagram, TikTok, Facebook, LinkedIn and YouTube. Any candidate tool has to either (a) cover a platform genuinely absent from this list, (b) beat ScrapeBadger/Babel Street on cost or data depth for a platform both already touch, or (c) plug the two `false` gaps (Bluesky, podcasts). Most of the 9 Apify actors compete directly with ScrapeBadger's existing coverage.

---

## 2. Tool-by-tool verdicts

### A. Apify actors

**1. [Social Media Hashtag Research](https://apify.com/apify/social-media-hashtag-research)** — bundle covering TikTok/Instagram/YouTube/Facebook hashtags.
- Data: captions, engagement, hashtags, timestamps, monetization flag.
- Cost: $2–5 per 1,000 results (varies by platform) + compute units.
- **Verdict: Redundant, skip.** Every platform it touches is already inside ScrapeBadger at $0.15/1,000 credits (~1 credit/request) — 3-30x cheaper than this bundle's $2-5/1,000, for the same platforms XTag already ingests via Babel Street/ScrapeBadger. No new coverage.

**2. [Instagram Hashtag Scraper](https://apify.com/apify/instagram-hashtag-scraper)** — dedicated Instagram hashtag/keyword actor.
- Data: rich (10 comments, likes/comments/shares, tagged users, music).
- Cost: $2.30/1,000, tiered down with volume.
- **Verdict: Redundant, skip.** Instagram is already in ScrapeBadger. This actor is more feature-rich per-post (deeper comment sampling) but not enough to justify a second Instagram pipeline unless ScrapeBadger's Instagram hashtag mode is proven weaker in practice — worth a spot-check, not a swap.

**3. [Telegram Channel Scraper](https://apify.com/monkey.d.scraping/telegram-channel-scraper)** (monkey.d.scraping)
- Data: full message history, reactions (emoji-level), views, polls, forwards/replies, link previews, channel metadata — no login required.
- Cost: $0.20/1,000 posts, ~6s/1,000 messages.
- **Verdict: Adopt — strongest candidate in the list.** Telegram is the one channel in XTag's live stack that is *not* backed by a named vendor (just "23 channels" of unknown scraping quality) — and Telegram is exactly where Hezbollah/Iran-aligned psychological-warfare content concentrates, XTag's original mandate. This actor is purpose-built, cheap, structured, supports monitor-mode for scheduled incremental pulls, and returns reaction/view data current XTag's Telegram integration may not surface. This is very likely **better than the current thing being used** for this one channel.

**4. [Threads Hashtag Scraper](https://apify.com/themineworks/threads-hashtag-scraper)**
- Data: text, author, engagement, media, permalinks; monitor mode for new-only pulls.
- Cost: $1.20/1,000 posts.
- **Verdict: Adopt — fills a real gap.** Threads is on neither ScrapeBadger's list nor visible in XTag's `/api/status`. Cross-platform narrative migration (X → Threads) is explicitly one of XTag's planned capabilities ("cross-platform migration" signal), so this is a genuine coverage gap, not a duplicate.

**5. [Likee Scraper](https://apify.com/innovatica-ai/likee-scraper)**
- Data: 30+ fields, engagement rate, creator info; residential proxy required for video-URL mode.
- Cost: from $5/1,000.
- **Verdict: Low priority, skip for now.** Likee isn't a primary platform for any of XTag's named priority regions (Russia, China, India, Taiwan, South Korea, Japan, Hezbollah-adjacent MENA). Niche audience (SE Asia/some MENA youth). Only revisit if a specific investigation surfaces Likee-based narrative activity.

**6. [Social Trends Scraper](https://apify.com/steadyfetch/social-trends-scraper)** (X, TikTok, Pinterest, YouTube Charts, Google)
- Data: normalized trend rows (rank, title, metric, country) across 5 platforms in one call.
- Cost: from $1.00/1,000 trend rows.
- **Verdict: Complementary, worth a trial.** This is a different *kind* of signal than post-level scraping — it's exactly the "sudden change in topic volume/engagement" early-detection feed XTag's spec calls for, normalized across platforms in one schema rather than five separate integrations. X trends overlap partly with ScrapeBadger's Twitter trends endpoint, but the multi-platform normalization (esp. Pinterest/Google Trends, which nothing in the current stack covers) is new. Cheap enough to pilot as a lightweight "pulse" layer feeding the narrative-velocity module.

**7. [Truth Social Posts Scraper](https://apify.com/maximedupre/truth-social-posts)**
- Data: ~40 fields/post, engagement, polls, reblogs; **profile-URL based only — no keyword/hashtag search.**
- Cost: $0.30/1,000 posts.
- **Verdict: Adopt for known-actor monitoring, not discovery.** Truth Social is absent from ScrapeBadger and not obviously covered by Babel Street's generic "social media" bucket. It matters for US-domestic political/conspiracy narrative tracking. The catch: it only monitors profiles you already know — good for the "actor/network mapping" capability (watch a defined list of influence accounts) but useless for open-ended hashtag discovery, so it's a narrow addition, not a replacement for anything.

**8. [Bilibili Video Scraper](https://apify.com/logiover/bilibili-video-scraper)**
- Data: views/likes/coins/danmaku (live scrolling comments)/favourites; **popular/ranking feed only — no keyword or channel search.**
- Cost: $2.10/1,000.
- **Verdict: Adopt with caveats.** Bilibili is China's largest video platform and directly on-mandate (China is a named target region), and nothing else in the stack — not ScrapeBadger, not GDELT, not SerpAPI — reaches it. The danmaku field is a genuinely unique live-sentiment signal not available elsewhere in the toolkit. But it's capped to the trending/ranking feed (~600-700 rolling videos, no archive, no targeted search), so it's a trend-radar, not a targeted-investigation tool — pair it with manual channel follow-ups rather than expecting hashtag-style queries.

**9. [LinkedIn Batch Profile Posts Scraper](https://apify.com/khadinakbar/linkedin-batch-profile-posts-scraper)**
- Data: post text, hashtags, activity type, posting cadence, up to 200 profiles/run.
- Cost: $0.006/saved post + negligible run fee.
- **Verdict: Redundant, skip.** LinkedIn is already inside ScrapeBadger. This actor's only differentiator is bulk profile-list monitoring (up to 200 known accounts at once) rather than search — useful *pattern* (watchlist-style monitoring) but ScrapeBadger's LinkedIn endpoints can likely be scripted to do the same at comparable or lower cost without adding a second vendor.

### B. Standalone scraping platforms

**10. [ScrapingBee](https://www.scrapingbee.com)** — general HTML/JS-rendering scraping API, e-commerce/SERP-focused prebuilt endpoints, no dedicated social actors.
- Pricing: $49-599+/mo subscription tiers, SOC2/GDPR.
- **Verdict: Skip — redundant category.** This occupies the exact same slot ScrapeBadger already fills (generic anti-bot scraping API), with a flat monthly-subscription model instead of ScrapeBadger's pay-per-credit model, and *no* social-platform-specific actors. Adding it fragments infrastructure for no new capability.

**11. [PhantomBuster](https://phantombuster.com/phantombuster)** — LinkedIn-centric growth/outreach automation ("Phantoms" for connection requests, DM sequences, profile scraping via session cookies).
- Pricing: $69-439+/mo.
- **Verdict: Skip — wrong tool category.** PhantomBuster is a sales/outreach automation tool, not a monitoring tool — its core value (auto-sending connection requests and messages) is irrelevant and arguably counterproductive for a *passive* narrative-intelligence platform. It logs in as a real account via stored cookies, which risks account bans and is a bad fit for anonymous, at-scale OSINT collection. Worse than the current approach on every axis that matters for XTag.

**12. [BrowserAct](https://www.browseract.com)** — natural-language-prompted AI browser agent, credit-based, launched its current "Agent Build" feature in July 2026.
- **Verdict: Skip for the core pipeline; maybe useful for ad-hoc analyst tasks.** It's designed for one-off exploratory scraping via prompts, not scheduled structured ingestion into a live dataset — the opposite of what an automated narrative pipeline needs. Very new product (weeks old), unproven reliability. Could be handed to an analyst for a single bespoke investigation, but shouldn't replace anything in the pipeline.

**13. [Octoparse](https://www.octoparse.com)** — no-code visual/drag-and-drop scraper, desktop + cloud.
- **Verdict: Skip — a step backward.** Built for non-technical users hand-building scrapers per target site. XTag's stack is already API-first and automatable (ScrapeBadger, Babel Street, GDELT); introducing a GUI-driven tool would reduce automation maturity rather than improve it.

**14. [scrape.do](https://scrape.do)** — general scraping/proxy API, prebuilt endpoints for major sites, "coming soon" proxy/browser products.
- **Verdict: Skip — redundant category**, same reasoning as ScrapingBee. No social-specific differentiation over ScrapeBadger, which XTag already pays for and has already integrated.

*(Note: the LinkedIn actor link was supplied twice in the request — evaluated once above as #9.)*

---

## 3. Prioritized recommendations

| Priority | Tool | Why |
|---|---|---|
| **1 — High confidence** | Telegram Channel Scraper (monkey.d.scraping) | Replaces an unverified bespoke Telegram integration with a purpose-built, cheap, structured one — directly on XTag's original Hezbollah/psy-ops mandate. |
| **2 — High confidence** | Threads Hashtag Scraper | Closes a real platform gap XTag's own "cross-platform migration" capability depends on. |
| **3 — Strong, on-mandate** | Bilibili Video Scraper | Only route into China's largest video platform; unique danmaku sentiment signal; matches the named China priority. Accept the ranking-feed-only limitation. |
| **4 — Worth piloting** | Social Trends Scraper | Cheap multi-platform "narrative velocity" pulse feed (esp. Pinterest/Google Trends, which nothing else covers) for the early-emergence-detection feature. |
| **5 — Narrow but useful** | Truth Social Posts Scraper | Only if you maintain a watchlist of specific US political/conspiracy accounts — not a discovery tool. |
| **Skip (redundant with ScrapeBadger/Babel Street)** | Social Media Hashtag Research bundle, Instagram Hashtag Scraper, LinkedIn Batch Profile Posts Scraper, ScrapingBee, scrape.do | Same platforms, worse pricing or no new capability vs. what's already live. |
| **Skip (wrong tool category)** | PhantomBuster, Octoparse, BrowserAct | Outreach automation, no-code GUI, and ad-hoc agent tooling respectively — none match a scheduled, passive, API-first intelligence pipeline. |
| **Skip (low mandate fit)** | Likee Scraper | Not a priority-region platform; revisit only if a specific case needs it. |

## 4. Risk notes

- **Third-party Apify actor risk:** unlike Babel Street/ScrapeBadger (which are the maintainers' core product), community actors (monkey.d.scraping, themineworks, innovatica-ai, steadyfetch, maximedupre, logiover, khadinakbar) are maintained by individual/small-team publishers. They can break silently when a platform changes its layout, with no SLA. Budget for monitoring and a fallback if adopting any of the "Adopt" picks above.
- **ToS/legal exposure:** scraping X/Instagram/LinkedIn/TikTok directly (rather than through their official APIs) sits in a legal grey zone in most jurisdictions; this is presumably already accepted risk given ScrapeBadger/Babel Street are already in production, but it applies equally to any new actor added.
- **PhantomBuster specifically** carries account-ban risk since it operates through logged-in session cookies — a materially different (and worse, for XTag's passive-monitoring use case) risk profile than the read-only actors above.
