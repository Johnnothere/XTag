# XTag — Handover Package

**Handed to the International Institute for Counter-Terrorism, Reichman University**
**Tej Gohil · 7 September 2026**

XTag searches a topic across sixteen public sources in over a hundred languages, removes what is
off-topic, and answers five questions about what remains: what is being said, who is saying it,
whether the spread is authentic, to whom it is aimed, and whether anything happened offline.

---

## Read this

**`XTag-Handover-Guide.docx`** — 9 pages. What XTag is, where it came from, what it does and does
not do, which ICT desks it serves, which publications it would have supported, what it costs, and
what to do first. That is the whole story; everything else is reference.

Then, only if you need it:

- **`02-operations/TECHNICAL-REFERENCE.md`** — the full analyst-level and engineering detail.
- **`02-operations/RUNBOOK.md`** — deploy, monitor, diagnose, recover.
- **`04-ict/INTERN-PROGRAMME.md`** — ten scoped intern projects.

---

## Contents

```
00-START-HERE.md                  This file
XTag-Handover-Guide.docx          The guide, 9 pages
XTag-Handover-Guide.pdf           The same, for circulation
XTag-Handover-Guide.md            Its markdown source

01-source-code/                   Complete source snapshot with its README
                                  SNAPSHOT-PROVENANCE.txt records the exact commit

02-operations/
  TECHNICAL-REFERENCE.md          Full analyst + engineering detail
  RUNBOOK.md                      Deploy, monitor, diagnose, recover
  ENV-REFERENCE.md                Every environment variable

03-research-and-decisions/        17 documents written during the build

04-ict/
  ICT-CAPABILITY-MAP.md           Desk matrix, publication case reviews, and how to
                                  phrase XTag findings in an ICT publication
  INTERN-PROGRAMME.md             Ten scoped intern projects
```

---

## The four things to do first

1. **Transfer the repository and the Railway deployment** to ICT accounts, and **rotate every API
   key** — all are currently personal.
2. **Set `XTAG_API_KEY`, `REPORTS_CRON_TOKEN` and `DEBUG_TOKEN`.** Without the first, every
   money-spending route is open to anyone with the URL.
3. **Hit `/healthz?deep=1`** and read `persistence.writable`, `claude`, `gdelt`, `mailer`.
4. **Plan the baseline run.** XTag's coordination detector currently returns a magnitude with no
   risk band, because it refuses to band a number it has nothing to compare against. Running the
   harness against ICT's real query set converts every coordination number the tool will ever
   produce into a finding. A fortnight of intern work. Guide §10, item 1.

---

**Repository:** `github.com/Johnnothere/XTag` · **Deployment:** Railway
**Contact:** Tej Gohil — tej.gohil0605@gmail.com
