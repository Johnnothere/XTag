---
title: "XTag — Handover to ICT"
subtitle: "Cross-platform narrative and coordination intelligence"
author: "Tej Gohil · Counter-Terrorism and National Security Analyst, ICT, Reichman University"
date: "7 September 2026"
---

## 1. What XTag is

XTag searches a topic across sixteen public sources in over a hundred languages, removes what is
off-topic, and answers five questions about what remains:

1. **What is being said** — the recurring narratives, their claims, their framing.
2. **Who is saying it** — actors, entities and relationships, each with a verbatim quote.
3. **Whether the spread is authentic** — whether distinct accounts are behaving as a coordinated
   set, measured against a synthetic-campaign benchmark.
4. **Where and to whom** — which countries' media carry it and in which languages.
5. **Whether anything happened offline** — protests, arrests, official acts, platform
   enforcement, published attributions.

It then produces a scored assessment, a written brief and a printable dossier.

**What makes it different is not the analysis. It is that every claim it makes can be checked.**
The filter shows what it dropped and why. The threat score opens into its factors. The
coordination detector refuses to give a risk band unless it has a baseline to compare against.
Quotes are verified against the corpus and deleted if not found. Where a stage did not run, the
report says so instead of printing a zero.

No commercial vendor in this category publishes accuracy, precision/recall, or a coverage
matrix. XTag publishes a measured detection floor.

**Current state:** live at `xtag.up.railway.app`. About 10,300 lines of Python, a single-file
frontend, 17 test suites, and a red-team measurement harness. Runs on free data sources plus
roughly $60–90/month of paid API capacity.

## 2. Where it came from

It started as a question about Hezbollah — specifically the decentralised network of channels,
accounts and sympathetic amplifiers around its cyber and information apparatus, and how a single
claim moves outward from it. That is **attack amplification**, and it has no manual answer at
scale: reading channels one at a time tells you what was said, not how many distinct actors
carried it, whether they moved together, or whether the audience was captured or manufactured.

Looking for existing tooling led first to **Social Searcher** — one query, many platforms, one
feed. It showed the shape of the answer and the ceiling: no narratives, no actor network, no way
to tell an organic surge from a coordinated one, no memory.

Digging further led to **Blackbird.AI** and the commercial narrative-intelligence vendors. They
solve the right problem, and they are expensive, closed and unpublished — none of them state how
well their detection works, on what, or against what baseline.

**XTag sits between the two.** It has the analytical layer Social Searcher lacks. It does not
have the scale or support organisation of Blackbird.AI and does not pretend to. What it has that
neither has is its working shown.

The original question survives in the design: GDELT is the backbone rather than one source among
sixteen; cross-lingual query expansion into Arabic, Persian and Hebrew runs on the critical path;
and reach is split into captured versus manufactured.

## 3. What it does

An analyst types a query in any script. In about **8 seconds** the first screen appears — the
documents collected, from which platforms, in which languages, with off-topic material already
removed and listed separately so the filter can be checked. In another **20–35 seconds** the
interpretation lands.

### Sources

| Source | Value | Cost |
|---|---|---|
| **GDELT** | Global news, 100+ languages, refreshed every 15 min. Tone, volume, source-country and language time series | Free |
| **State media RSS** (17 feeds) | Al-Manar, Al Mayadeen, Mehr, IRNA, Tasnim, PressTV, Khamenei.ir, RT, TASS, CGTN — **in their own languages** | Free |
| X / Twitter | Both Top and Latest; Latest is where coordination lives | Paid |
| Telegram | 20 curated public channels | Free |
| TikTok, Instagram | Keyword and hashtag search, region-selectable | Paid |
| Reddit, YouTube, Bluesky, Mastodon, Hacker News, Google News | Free tiers | Free |
| Facebook, LinkedIn, Threads, Google Web | Via SerpApi | Paid |
| OpenAlex, arXiv, Podcast Index, NotebookLM | Academic, podcasts, own knowledge bank | Free |

The state-media feeds matter for ICT specifically: they are read in Arabic, Persian and Russian
as well as English, and the native-language edition is treated as the higher-value target —
because the Persian and English editions of Mehr are frequently not saying the same thing, and
the difference is the finding.

### The five outputs

**Narratives** — up to eight recurring frames, each with a label, a key claim, a framing, the
platforms it runs on, and the documents carrying it. Narratives have **persistent identity
across runs**, so the system can say "N-2871, first seen 14 May, +34% this week, split Tuesday".

**Coordination** — actor clusters sharing distinctive traits (canonicalised URLs, hashtag sets,
text shingles, five-minute posting buckets), weighted by published detection reliability. Output
is a 0–100 magnitude plus the clusters, actors and flagged documents.

**Reach split** — of the measurable engagement, what share came from inside a detected cluster
(manufactured) and what from outside it (captured), against Ferrara's 0.1–5.3% reference band for
confirmed state operations.

**Assessment** — a 0–100 threat score over eight weighted factors, four risk dimensions
(reputational, information integrity, operational, physical security), and an inauthenticity
score over five campaign-shape signals. Every score carries its factors, weights, real
contributions, and reasons for absence.

**Real-world events** — offline events evidenced in the corpus, each with a quoted phrase. The
stage returns nothing when nothing qualifies, by design.

## 4. What it does not do

Stated plainly so nobody discovers it in front of a client.

- **It is not a bot detector.** Account age, follower graphs and posting history are not
  available from any source it uses. Its inauthenticity detection is campaign-shape analysis. No
  claim is ever made that a specific account is automated.
- **Its physical-security dimension is lexical screening, not threat assessment.** It flags
  violent vocabulary for human review. On conflict topics it runs hot by construction.
- **Its threat weights are not backtested.** They are transparent and defensible, set from domain
  reasoning and synthetic scenarios — not calibrated against labelled historical incidents.
- **Coordination is unbanded out of the box.** The baseline is unset, so every report currently
  says "no matched organic baseline". This is deliberate, and fixing it is the first job (§9).
- **Semantic clustering is built but not switched on.** A narrative restated in genuinely
  different vocabulary will currently split into two.
- **There is no continuous background monitoring.** Watchlists are evaluated on demand; recurring
  email reports are driven by an external cron, not a worker process.
- **"Origin" is a collection artefact.** Coverage is uneven, so a story that began somewhere
  poorly covered appears to start wherever collection is strongest. The payload says so.
- **Two licensing constraints.** Reddit's free API is research-use only; TikTok's Research API is
  academic/non-profit only, so XTag reaches TikTok through a commercial scraper. ICT should make
  both decisions consciously.

## 5. Why this matters to ICT now

XTag is directly useful to six of ICT's eleven desks, partly useful to three, and not relevant to
two. Being specific is more useful than claiming it helps everyone.

| Desk | Fit | What it supplies |
|---|---|---|
| **Influence** | Direct | The whole product. Narrative identification over time, coordination with a measured detection floor, the reach split, audience inference, hostile-tone trend |
| **Terrorism & Cyber** | Direct | The monthly trend report as a scheduled run against standing queries; hacktivist-persona work as an actor-trait problem |
| **Iran & Shi'ite Terrorism** | Direct | Persian read natively; Mehr, IRNA, Tasnim, PressTV, Khamenei.ir in the standing feed set; narrative-laundering detection from state media into unattributed sources |
| **Palestinian Terrorist Organizations** | Direct | The same in Arabic — Al-Manar, Al Mayadeen, Al Jazeera Arabic, with correct Arabic-script matching |
| **Terrorism and the Media** | Direct | Which countries' media carry a narrative, in which languages, and how concentrated — a direct answer to "domestic story or international campaign" |
| **Antisemitism & Far-Right** | Direct | Same mechanism, different vocabulary. Gaming platforms are not covered; the surrounding discourse is |
| **Global Jihad** | Partial | Good on public amplification, weak on the encrypted channels where primary material sits |
| **Terrorism & Psychology** | Partial | Framing and native-language sentiment as description, not detection |
| **Resilience & Civilian Defense** | Partial | Watchlists and alerting on domestic-facing narratives |
| **CBRN · International Law** | None | Nothing beyond generic media monitoring |

**Services.** Two of ICT's four consulting lines map cleanly. **Threat Assessment & Risk
Analysis** gets four separately-owned risk dimensions, with the operational dimension withheld
unless a client subject is explicitly configured — so a report cannot silently assert a subject
nobody entered. **War Games & Simulations** gets the injection harness: synthetic influence
campaigns of six evasion types with known ground truth, ready-made as a red-team component.
Counter-terror financing and legal support are out of scope.

## 6. Publications it would have supported

XTag would not have written any of these or replaced their analysis. It would have converted
qualitative assertions into measured, citable evidence.

| ICT publication | What XTag adds |
|---|---|
| **Bibi Gate: Handala Hack Team** (Dec 2025) | The amplification half of the argument: actor clusters, the traits that linked them, coordination magnitude with a baseline ratio, reach split, propagation with per-hop lag. Including the negative result if there is one |
| **Hezbollah's Influence Warfare — Al-Khanadeq** (Nov 2025) | The original XTag question. Telegram collection, actor clustering across X/Telegram/TikTok, and how much of the channel's measurable reach is its own accounts |
| **Iran's Information Warfare During the Dec 2025–Jan 2026 Protests** (Feb 2026) | Volume series with the peak in σ above baseline; source-country and language breakdowns; tone trend; a dated record of which narratives were born, grew, drifted and died |
| **Iranian TikTok Campaign Using AI** (Jun 2025) | Direct fit — TikTok collection plus the relevance filter, which exists because platform rankers substitute the nearest token they can match |
| **A Narrative of Victimhood** (Mar 2026) · **From Missiles to Minds** (Apr 2026) | Narrative extraction produces exactly the object both papers describe; tracking turns a snapshot into a trajectory |
| **Cyber-Terrorism Desk Monthly Trend Report** | The clearest operational fit: standing queries on a schedule, producing a dated snapshot with a first-versus-last delta. Already works as an email subscription |
| **Gaming/radicalisation studies** | Partial. Discord, Roblox and Steam are not sources. Covers the surrounding amplification, not the ethnographic core |

**The honest summary:** in every case the contribution is the same three things — a countable
corpus with a stated collection method, a coordination measurement with a stated detection floor,
and a time series so that "this is growing" is a measurement rather than an impression. It does
not contribute interpretation, regional expertise, or access to closed sources. That is the
correct division of labour and the reason it is worth having.

## 7. Why this matters to ICT's future

**Interns.** The recurring failure of a twelve-week research internship is that four weeks go on
acquiring collection technique and the output is a literature-shaped paper the desk could have
written faster. With a running XTag instance, week one produces a countable, dated, multilingual
corpus with the method stated. The scarce resource becomes interpretation — the thing the
internship is meant to teach. Five projects worth running first:

1. **Set and publish the detection floor** — run the harness against twenty representative ICT
   queries; report recall, precision and breaking point; set the baseline. Would be the only
   published detection benchmark in the category.
2. **A twelve-month narrative time series** on one named channel or persona.
3. **Replicate a persona study with measured coordination** — strengthen or honestly contradict
   an existing ICT publication.
4. **The coverage matrix** — what each of the sixteen sources actually returns across five
   languages. Cheapest project here and one of the most useful.
5. **A red-team exercise for War Games** — inject a campaign of known ground truth, measure how
   long analysts take to find it.

Ten projects with week-by-week structure are in `04-ict/INTERN-PROGRAMME.md`.

**Publications.** A review of nine reports from a leading commercial narrative-intelligence firm
found none of them stated N, the date range, the source count or the languages; none carried
confidence language, alternative hypotheses or an intelligence-gaps section; and every
coordination judgement was asserted rather than shown. ICT publications built on XTag can state
all five, and four already exist in the payload. That is a differentiator available immediately,
and one funded competitors cannot copy quickly — copying it means publishing their numbers.

**The World Summit and the Certificate Program.** A session in which a campaign of known ground
truth is injected into a real corpus and the audience watches the detector recover it — including
the sizes at which it fails — is a stronger demonstration than a slide claiming capability. For
teaching, XTag is a concrete object lesson in the difference between a measurement and an
assertion.

**Institutional memory.** Every search run with persistence enabled writes a permanent row into
the snapshot table. Over a year that becomes a time series of how ICT's own subjects moved —
mention volume, coordination, sentiment, narrative births and deaths — that no analyst's notes
can reconstruct. It accrues from the day it is switched on and cannot be back-filled.

## 8. How it works, in brief

Six stages. Only the last uses a language model.

```
1  PLAN      Expand the query into Arabic / Persian / Hebrew and into its
             plausible written forms.
2  COLLECT   Sixteen sources in parallel. Anything that misses the deadline
             is marked "timed out" by name, never dropped silently.
3  CLEAN     Deduplicate news URLs (never social posts — co-sharing is the
             strongest coordination signal). Score every document for
             relevance; keep a sample of what was dropped, with reasons.
   ─────────  FIRST SCREEN (~8 seconds) ─────────
4  DESCRIBE  Language detection; sentiment and framing scored natively in
             each language.
5  MEASURE   Coordination clustering, velocity, propagation, and the GDELT
             tone / volume / country / language snapshot.
6  INTERPRET Narratives, entities, real-world events. Then the deterministic
             assessment layer scores threat, risk, inauthenticity, audience.
```

**Why stage 3 exists.** Measured on the live deployment: the query `#covid1948` returned 530
documents of which **389 (73.4%) contained no form of the query at all** — YouTube alone supplied
450 generic COVID-19 videos. Sentiment was computed over that noise, narratives were extracted
from it, and the confidence formula, which reads document count, reported 94.5 ("high")
*precisely because there were 530 documents*. Unfiltered noise does not merely add error; it
certifies it.

**Why coordination is measured by traits and not text.** Published detection reliability: shared
URL 0.72 AUC, shared hashtag 0.60, **text similarity 0.52** — barely above chance, and text
similarity is what the previous detector counted. Against the injection harness that detector
scored 0% recall on all six campaign types and 16–96 on corpora containing no campaign at all.
The replacement scores **100% recall, 97–100% precision, and exactly 0 on organic traffic** at a
32-document campaign.

**Why the score refuses to band itself.** Ferrara's re-analysis of seven government-attributed
state campaigns (25 million tweets, 9,071 accounts) with a matched organic baseline found
confirmed operations sit **7–70× above baseline**. A cluster at 1.3× is a fandom. Without a
baseline, a coordination number is a magnitude with nothing to compare it to, and XTag says so
rather than inventing a band.

The full analyst-level and engineering detail is in `02-operations/TECHNICAL-REFERENCE.md`.

## 9. Running it

| Item | Cost | Required? |
|---|---|---|
| Railway hosting | ~$5–20/mo | Yes |
| Anthropic API | ~$20–40/mo | Yes — no narrative engine without it |
| Supabase (free tier) | $0 | Strongly recommended — no history without it |
| ScrapeBadger (X, TikTok, Instagram) | ~$30–50/mo | No — those three go dark |
| SerpApi (Facebook, LinkedIn, Threads) | ~$50/mo | No |
| GDELT, state media, Reddit, YouTube, Telegram, academic, and seven others | **$0** | — |

**Minimum: about $25–60/month.** That gives GDELT, all the free sources, state media, and the
entire analysis and scoring layer. **Full coverage: about $105–160/month.** Every source degrades
independently and by name — there is no all-or-nothing dependency anywhere.

**Staffing:** an owner, not a team. Two to four hours a month for routine operation, plus
whatever project work is scheduled. A competent Python developer is productive in it inside a day.

### The first week

1. **Transfer the repository and the Railway project** to ICT-controlled accounts.
2. **Rotate every key** — Anthropic, ScrapeBadger, SerpApi, YouTube, Reddit, Supabase, Resend.
   All are currently personal.
3. **Set `XTAG_API_KEY`, `REPORTS_CRON_TOKEN` and `DEBUG_TOKEN`.** Without the first, every
   money-spending route is open to anyone who has the URL.
4. **Hit `/healthz?deep=1`** and read four fields: `persistence.writable` (false here almost
   always means the anon key was used instead of the service_role key), `claude`, `gdelt`,
   `mailer`.
5. **Run `bash tests/run.sh`** — no dependencies, no network.
6. **Set `TIKTOK_REGION`** before any MENA work; it defaults to `US`.
7. **Plan the baseline run** (below).

## 10. Known limits, in priority order

| # | Limit | What to do |
|---|---|---|
| 1 | **Coordination is unbanded.** Every report says "no matched organic baseline" | Run `harness.baseline_ratio()` against representative ICT queries and set `COORDINATION_BASELINE`. **Do not guess it** — the whole design exists because absolute thresholds called organic traffic high-risk. A fortnight of intern work |
| 2 | **Narrative identity lives in the cache table with a 90-day expiry** | A pruned row silently resets every narrative ID for that query. Give it its own table |
| 3 | **Threat weights are not backtested** | Backtest against GDELT's BigQuery archive on known incidents, or state the limit in publications |
| 4 | **The app must run on one worker** | Cache, watchlists, rate limiter and circuit breaker are all in-process. Move them to Redis or Postgres before raising the worker count |
| 5 | **Semantic clustering is built but unused** | Wire it in, or rename the field that reports it — a reader could infer it is running |
| 6 | **Two migrations conflict** on the subscription tables | Verify which one applied before writing ops documentation |
| 7 | **No continuous monitoring** | Build a worker process, or document the limitation |

**Governance.** Babel Street, an optional second sentiment engine (off unless a key is set), was
named by Amnesty International in August 2025 over location-data surveillance. One line to
remove. More broadly: the counter-disinformation buyer was dismantled while the budget that grew
was domestic surveillance and corporate reputation — Graphika repositioned into fraud and brand,
Zignal sells to ICE. **The most predictable way this category damages the organisations in it is
by drifting from counter-terrorism analysis into population monitoring.** XTag collects only
public content, makes no claim about any individual account, and refuses to profile. Those are
design decisions and they are reversible. ICT should decide its position before the first
external engagement.

## 11. Where everything is

```
XTag-Handover/
├── 00-START-HERE.md
├── XTag-Handover-Guide.docx / .pdf / .md    This document
├── 01-source-code/          Complete source snapshot + README + provenance
├── 02-operations/
│   ├── TECHNICAL-REFERENCE.md   The full analyst and engineering detail
│   ├── RUNBOOK.md               Deploy, monitor, diagnose, recover
│   └── ENV-REFERENCE.md         Every environment variable
├── 03-research-and-decisions/   17 documents written during the build
└── 04-ict/
    ├── ICT-CAPABILITY-MAP.md    Desk matrix + publication phrasing
    └── INTERN-PROGRAMME.md      Ten scoped intern projects
```

**Repository:** `github.com/Johnnothere/XTag` · **Deployment:** Railway ·
**Contact:** Tej Gohil — tej.gohil0605@gmail.com

---

*One closing note. This document is deliberately unflattering about XTag in places. That is the
same rule the software follows: a tool used for threat assessment that overstates what it knows
is worse than no tool, and the institute publishing on the basis of an overstated number carries
the cost. Every limitation here is stated because someone would otherwise find it at the wrong
moment.*

*The most valuable next step is not a feature. It is the baseline run — a fortnight of work that
converts every coordination number XTag will ever produce from a magnitude into a finding.*
